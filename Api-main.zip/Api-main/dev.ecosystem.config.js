module.exports = {
  apps : [{
    name: "dev-api",
    namespace: "dev",
    script: "./dist/main.js",
    watch: true,
    ignore_watch:['node_modules','dist'],
    env: {
      NODE_ENV: "development",
    },
  }]
}