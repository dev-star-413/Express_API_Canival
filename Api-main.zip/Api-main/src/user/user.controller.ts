import { Body, Controller, Delete, Get, Param, Post, Put, Req, Res, UploadedFile, UploadedFiles, UseInterceptors } from '@nestjs/common';
import { HttpException, HttpStatus } from '@nestjs/common';
import { Request, Response } from 'express';
import { UserService } from './user.service'
@Controller('user')
export class UserController {
    constructor(private userServices: UserService) { }
    @Post("/login/google")
    async googleLogin(@Req() req): Promise<any> {
        let header = req.headers
        let user = await this.userServices.googleAuth(header);
        return user;
    }
    // send user identity to the profile page
    @Get('/')
    async getUser(@Param() param, @Req() req: Request, @Res() res: Response): Promise<any> {
        res.json(await this.userServices.get(res.locals.userId))
    }

    @Post('/login/facebook')
    async FacebookLogin(@Body() body,@Req() req): Promise<any> {
        const header=req.headers
        let res=await this.userServices.faceookAuth(header,body)
        return res
    }
    // update profile
    @Put("/profile")
    async updateProfile(@Body() body, @Res() res: Response): Promise<any> {
        if (!res.locals.userId) throw new HttpException('Please Login, Not Found Your Account.', HttpStatus.NOT_FOUND);
        res.json(await this.userServices.updateProfile(body))
    }
    // delete all token which belong to the user
    @Delete("/logout")
    async logout(@Res() res: Response): Promise<any> {
        res.json(await this.userServices.logout(res.locals.userId))
    }
    @Post("/profile/picture")
    async profilePicture(@Body() body,@Res() res): Promise<any> {
        return res.json(await this.userServices.uploadProfilePicture(body,res));
    }
    @Delete("/profile/picture")
    async removeProfilePicture(@Body() body,@Res() res): Promise<any> {
        return res.json(await this.userServices.removeProfilePicture(body,res));
    }
}
