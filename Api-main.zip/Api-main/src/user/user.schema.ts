import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type UserDocument = User & Document;

@Schema()
export class User {
  @Prop({ trim: true })
  uName: string;

  @Prop({})
  password: string;

  @Prop({ default: "user" })
  role: string;

  @Prop({ trim: true })
  name: string;

  @Prop({ trim: true })
  dName: string;

  @Prop({ trim: true })
  insta: string;

  @Prop()
  tz: string;

  @Prop({ required: true, default: Date.now })
  createAt: Date;

  @Prop()
  deleteAt: Date;

  @Prop({ trim: true })
  email: string;

  @Prop()
  pic: string;

  @Prop()
  bDate: Date

  @Prop({ trim: true })
  desc: string
  
  @Prop({ trim: true })
  web: string
  
  @Prop({ trim: true })
  twitter: string
  
  @Prop({ trim: true })
  facebook: string
  
  @Prop({ })
  otherSocial: string

  @Prop({type:[String]  })
  countries: String[]

  @Prop({type:Object  })
  organizeBand: object //{_id, name, isVerify} 

  @Prop({type:Object}) // {name, path , mime}
  img:object
}

export const UserSchema = SchemaFactory.createForClass(User)