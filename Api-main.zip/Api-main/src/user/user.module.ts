import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UserController } from './user.controller';
import { UserService } from './user.service';
import { UserSchema, User } from './user.schema'
import { TokenSchema } from '../token/token.schema';
import { bandDateSchema } from 'src/band/bandDates/band-date.schema';
import { bandTempSchema } from 'src/band-temp/band-temp.schema';
import { EventSchema } from 'src/event/event.schema';
import { EventTempSchema } from 'src/event-temp/event-temp.schema';
import { WatchListSchema } from 'src/watch-list/watch-list.schema';
import { SectionSchema } from 'src/section/section.schema';
import { DatesSchema } from 'src/dates/dates.schema';
import { BandSchema } from 'src/band/band.schema';
import { ServicesModule } from 'src/services/services.module';
import { CommentSchema } from 'src/comment/comment.schema';
import { HttpModule } from '@nestjs/axios';
import { FestivalSchema } from 'src/festival/festival.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: 'User', schema: UserSchema },
            { name: "token", schema: TokenSchema },
            { name: 'BandDate', schema: bandDateSchema },
            { name: 'BandTemp', schema: bandTempSchema },
            { name: 'Event', schema: EventSchema },
            { name: 'EventTemp', schema: EventTempSchema },
            { name: 'WatchList', schema: WatchListSchema },
            { name: 'Section', schema: SectionSchema },
            { name: 'date', schema: DatesSchema },
            { name: 'Band', schema: BandSchema },
            { name: 'Comment', schema: CommentSchema },
            { name: 'Festival', schema: FestivalSchema },
        ]),
        ServicesModule,
        HttpModule
    ],
    controllers: [UserController],
    providers: [UserService],
    exports: [MongooseModule.forFeature([
        { name: 'User', schema: UserSchema },
        { name: "token", schema: TokenSchema },
        { name: 'BandDate', schema: bandDateSchema },
        { name: 'BandTemp', schema: bandTempSchema },
        { name: 'Event', schema: EventSchema },
        { name: 'EventTemp', schema: EventTempSchema },
        { name: 'WatchList', schema: WatchListSchema },
        { name: 'Section', schema: SectionSchema },
    ])]

})
export class UserModule { }
