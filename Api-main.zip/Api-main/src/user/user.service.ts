import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User, UserDocument } from './user.schema'
import { TokensDocument } from '../token/token.schema';
import { BandDateDocument } from 'src/band/bandDates/band-date.schema';
import { BandTempDocument } from 'src/band-temp/band-temp.schema';
import { EventDocument } from 'src/event/event.schema';
import { EventTempDocument } from 'src/event-temp/event-temp.schema';
import { WatchListDocument } from 'src/watch-list/watch-list.schema';
import { SectionDocument } from 'src/section/section.schema';
import { DateDocument } from 'src/dates/dates.schema';
import { BandDocument } from 'src/band/band.schema';
import getConfig from 'src/config/config.service';
const { OAuth2Client } = require('google-auth-library');
import { join } from 'path';
import { unlink } from 'fs/promises';
import { FunctionsService } from 'src/services/functions.service';
import { CommentDocument } from 'src/comment/comment.schema';
import { HttpService } from '@nestjs/axios';
import { FestivalDocument } from 'src/festival/festival.schema';
const imagesPrefix = 'profiles';
const config = getConfig()

@Injectable()
export class UserService {
    constructor(
        @InjectModel('User') private UserModel: Model<UserDocument>,
        @InjectModel('token') private TokenModel: Model<TokensDocument>,
        @InjectModel('BandDate') private bandDateModel: Model<BandDateDocument>,
        @InjectModel('Band') private bandModel: Model<BandDocument>,
        @InjectModel('BandTemp') private bandTempModel: Model<BandTempDocument>,
        @InjectModel('Event') private eventModel: Model<EventDocument>,
        @InjectModel('EventTemp') private eventTempModel: Model<EventTempDocument>,
        @InjectModel("WatchList") private watchlistModel: Model<WatchListDocument>,
        @InjectModel('Section') private sectionModel: Model<SectionDocument>,
        @InjectModel("date") private DateModel: Model<DateDocument>,
        @InjectModel("Festival") private FestivalModel: Model<FestivalDocument>,
        @InjectModel('Comment') private CommentModel: Model<CommentDocument>,
        private functions: FunctionsService,
        private readonly httpService: HttpService
    ) {
    }
    private readonly clients = new OAuth2Client(config.webClientID);
    async googleAuth(params): Promise<any> {
        var idToken = params.tokenid
        var result = await this.clients.verifyIdToken({ idToken: idToken })
        result = result.getPayload()
        if (!result) return new Error("login failed");
        var email = result.email
        var user = await this.UserModel.findOne({ email })
        if (!user) {
            let data = {
                email,
                uName: result.name,
                dName: result.name,
                name: result.name,
                pic: result.picture
            }
            user = new this.UserModel(data)
            await user.save()
        }
        else {
            // Why do we have to update users profile pic?
            // user=await this.UserModel.findOneAndUpdate({_id:user._id},{pic:result.picture})
        }
        var token = this.functions.randomToken(32)
        let tokenData = {
            userId: user.id,
            token: token,
            email: user.email
        }
        let newToken = new this.TokenModel(tokenData);
        await newToken.save()
        let data = {
            user,
            token: newToken.token,
        }
        return data
    }
    async faceookAuth(params,body): Promise<any> {
        try {
            const userId=body.userID
            const accessToken=params.accesstoken
            if(!accessToken) return {code:-1,msg:"Failed"}

            const appToken = config.fbID + "|" + config.fbSecret;
            let isValid=await this.reverifyAccessToken(accessToken, appToken, userId)
            if(!isValid) return {code:-1, msg:"Your Facebook account is not valid.", data:{}}
            const url = `https://graph.facebook.com/v2.11/${userId}/?fields=name,picture,email&access_token=${accessToken}`;
            // get from facebook
            var result:any = await this.httpService.get(url).toPromise();
            console.log("--------------------------result")
            console.log(result.data)
            result=result.data
            if(!result.email) return {code:-1,msg:"Failed login"}
            var user = await this.UserModel.findOne({ email:result && result.email })
            if(!user){
                let data: any = {
                    email:result.email,
                    uName: result.name,
                    dName: result.name,
                    name: result.name,
                }
                if(result.picture && result.picture.data && result.picture.data.url) {
                  data.pic = result.picture.data.url;
                }
                user = new this.UserModel(data)
                await user.save()
            }
            var token = this.functions.randomToken(32)
            let tokenData = {
                userId: user.id,
                token: token,
                email: user.email
            }
            let newToken = new this.TokenModel(tokenData);
            await newToken.save()
            let data = {
                user,
                token: newToken.token,
            }
            return {code:0,msg:"success",data}
        } catch (error) {
           console.log(error)
           return {code:-1,msg:error.message}     
        }
    }
    async get(userId): Promise<any> {
        try {
            const user:any = await this.UserModel.findOne({ _id: userId }); // "_id email uName name bDate flags pic desc dName insta web facebook twitter countries"
            if(user && user.img && user.img.path)
                user.img.path=`${config.imgDomain}${config[imagesPrefix]}/${user.img.path}`;
            const eventTemps = await this.eventTempModel.find({ by: userId }, "_id name pitch type at");
            const bandTemps = await this.bandTempModel.find({ by: userId }, "_id name desc dateName at");
            const watchListTemp = await this.watchlistModel.find({ userId });
            const watchList = [];
            for (const item of watchListTemp) {
                switch (item.collName) {
                    case 'Band':
                        var band = await this.bandDateModel.findById(item.caseId, "name year slug");
                        if (band) {
                            watchList.push({
                                _id: item._id,
                                name: `${band.name} ${band.year}`,
                                slug: band.slug,
                                type: 'Band',
                                prefix: '/bands',
                            });
                        }else {
                          band=  await this.bandModel.findById(item.caseId,'name slug')
                          if(band){
                            watchList.push({
                                _id: item._id,
                                name: `${band.name}`,
                                slug: band.slug,
                                type: 'Band',
                                prefix: '/band',
                            });
                          }
                        }
                        break;
                    case 'Section':
                        const section = await this.sectionModel.findById(item.caseId, "name bdId");
                        if (section) {
                            const bandOfSection = await this.bandDateModel.findById(section.bdId, "name year slug");
                            watchList.push({
                                _id: item._id,
                                name: section && section.name,
                                slug: bandOfSection && bandOfSection.slug,
                                type: `${bandOfSection.name} ${bandOfSection.year}`,
                                prefix: '/bands',
                            });
                        }
                        break;
                    case 'dates':
                        var dates: any = await this.DateModel.findOne({_id: item.caseId})                        
                        if (dates) {
                            watchList.push({
                                _id: item._id,
                                name: dates && dates.festival && dates.festival.name,
                                slug: dates && dates.slug,
                                type: `Festival`,
                                prefix: '/festivals',
                            });
                        }
                        break;
                    case 'festivals':
                        var fes: any = await this.FestivalModel.findOne({_id: item.caseId})                        
                        if (fes) {
                            watchList.push({
                                _id: item._id,
                                name: fes.name,
                                slug: fes.slug,
                                type: `Festival`,
                                prefix: '/festival',
                            });
                        }
                        break;
                    default:
                        break;
                }
            }
            return { user, eventTemps, bandTemps, watchList };
        } catch (error) {
            console.log(error);
            return { code: -1, msg: "Error occurred whiel getting data of user." }
        }
    }
    async updateProfile(body): Promise<any> {
        try {
            const { desc, flags, name, _id, bDate, dName, insta,countries,web,twitter,facebook,otherSocial,organizeBand } = body  
            if (_id && name) {
                var user:any=await this.UserModel.findById(_id,'organizeBand')
                var oBand:any={}
                if(user && user.organizeBand && user.organizeBand._id== organizeBand )
                    oBand=user.organizeBand
                else if(organizeBand){
                    var band= await this.bandModel.findById(organizeBand,'name')
                    if(band)
                        oBand={...band,isVerify:false}
                        await this.CommentModel.updateMany({userId:_id},{$unset:{isOrganizer:1}})

                }
                await this.UserModel.updateOne({ _id: _id },
                {
                    desc, flags, name, bDate, dName, insta ,
                    countries,web,twitter,facebook,otherSocial,
                    organizeBand:oBand
                })
                await this.CommentModel.updateMany({userId:_id},{name:dName})
                return {
                    code: 0,
                    msg: 'Profile updated successfully!',
                    data: await this.UserModel.findOne({ _id: _id }, "_id uName name email flags bDate desc dName insta")
                }
            }
            return { code: 1, msg: "Some parameters have been missed." }
        } catch (error) {
            return { code: -1, msg: "Error occurred while updating profile." }
        }
    }
    async logout(userId): Promise<any> {
        try {
            await this.TokenModel.deleteMany({ userId })
            return { code: 1, msg: 'Account logged out successfully.' }
        } catch (error) {
            return { code: -1, msg: 'Error occurred while logging out of this account.' }
        }
    }
    async uploadProfilePicture(body,res):Promise<any>{
        try {
            // Fix Error Handling, Delete last profile Picture
            var file=body.picture
            var userId=res.locals.userId

            var save:any=await this.functions.saveFiles(file,imagesPrefix);
            save=save && save[0]
            if(!save || !save.path) throw new Error("Failed upload file") 
            var user:any=await this.UserModel.findOneAndUpdate({ _id: userId },{img:save })
            await this.CommentModel.updateMany({userId:userId},{avatar:save.path})

            //mongoose return user before update by default
            if (user.img && user.img.path){
                var filepath = join(config.adminProjectPath, 'public',  config[imagesPrefix] || config["defaultImages"],user.img.path);
                console.log(filepath)
                unlink(filepath)
            }

            save.path = `${config.imgDomain}${config[imagesPrefix]}/${save && save.path}`;
            user.img=save
            return {code:0,msg:"Success",data:user}
        } catch (error) {
            return res.json({code:-1,msg:"Successfully Failed",data:error})
        }
    }
    async removeProfilePicture(body,res):Promise<any>{
        try {
            // Fix Error Handling, Delete last profile Picture
            var userId=res.locals.userId
            // Not sure if we have to remove google pic profile
            var user:any=await this.UserModel.findOneAndUpdate({ _id: userId },{ $unset: { pic:1, img: 1 } })
            //mongoose return user before update by default and user has pic and img inside
            this.CommentModel.updateMany({userId:userId},{ $unset: { avatar:1 }})
            if (user.img && user.img.path){
                var filepath = join(config.adminProjectPath, 'public',  config[imagesPrefix] || config["defaultImages"],user.img.path);
                console.log(filepath)
                unlink(filepath)
            }
            user=user.toObject()
            delete user.pic
            delete user.img
            return {code:0,msg:"Success",data:user}
        } catch (error) {
            return res.json({code:-1,msg:"Successfully Failed",data:error})
        }
    }
    async  reverifyAccessToken(accessToken, appToken, userId):Promise<any> {
        try {
            const url = `https://graph.facebook.com/debug_token/?input_token=${accessToken}&access_token=${appToken}`;
            var verify=false;
            let verifyRes=await this.httpService.get(url).toPromise()
            verifyRes=verifyRes.data
            if(verifyRes && verifyRes.data && verifyRes.data.is_valid,verifyRes.data.user_id==userId) verify=true
        
            return verify
        } catch (error) {
            console.log(error)
            return false
        }
      }
}