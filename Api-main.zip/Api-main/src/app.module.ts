import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { MongooseModule } from '@nestjs/mongoose';
import { FestivalModule } from './festival/festival.module';
import { NewsModule } from './news/news.module';
import { EventModule } from './event/event.module';
import { CommentModule } from './comment/comment.module';
import { BlogModule } from './blog/blog.module';
import { BandModule } from './band/band.module';
import { DesignerModule } from './designer/designer.module';
import { FaqModule } from './faq/faq.module';
import { TradeModule } from './trade/trade.module';
import { SectionModule } from './section/section.module';
import { QuoteModule } from './quote/quote.module';
import { LoggerMiddleware } from './middleware/loggermiddleware';
import { TokenModule } from './token/token.module';
import { AwardModule } from './award/award.module';
import { AdModule } from './ad/ad.module';
import { DatesModule } from './dates/dates.module';
import { BandDateModule } from './band/bandDates/band-date.module';
import { WatchListModule } from './watch-list/watch-list.module';
import { LineModule } from './line/line.module';
import { DynamicModule } from './dynamic/dynamic.module';
import { StaticsModule } from './statics/statics.module';
import { VoteModule } from './vote/vote.module';
import { EventTempModule } from './event-temp/event-temp.module';
import { BandTempModule } from './band-temp/band-temp.module';
import { ComparesModule } from './compares/compares.module';
import { GalleryController } from './gallery/gallery.controller';
import { GalleryModule } from './gallery/gallery.module';
import getConfig from "src/config/config.service";
const config = getConfig();

@Module({
  imports: [UserModule, MongooseModule.forRoot(config.dbUrl),
    AwardModule, DatesModule, AdModule, TokenModule, FestivalModule, NewsModule, EventModule,
    CommentModule, BlogModule, BandModule, DesignerModule, SectionModule,
    FaqModule, TradeModule, QuoteModule, TokenModule, BandDateModule, WatchListModule,
    LineModule,
    DynamicModule,
    StaticsModule,
    VoteModule,
    EventTempModule,
    BandTempModule,
    ComparesModule,
    GalleryModule,
  ],
  controllers: [AppController, GalleryController],
  providers: [AppService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware)
      .forRoutes('*');
  }
}
