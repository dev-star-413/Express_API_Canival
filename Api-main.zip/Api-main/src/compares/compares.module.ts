import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ComparesSchema } from './compares.schema';
@Module({
    imports:[MongooseModule.forFeature([{name:"Compares",schema:ComparesSchema}])],
    exports:[MongooseModule.forFeature([{name:"Compares",schema:ComparesSchema}])],
})
export class ComparesModule {}
