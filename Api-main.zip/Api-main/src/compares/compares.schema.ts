import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
export type ComparesDocument = Compares & Document;
@Schema()
export class Compares {
  @Prop({type:String})
  dateIdA:string 
  @Prop({type:String})
  bandDateIdA:string 
  @Prop({type:String})
  sectionIdA:string 
  @Prop({type:String})
  dateIdB:string 
  @Prop({type:String})
  bandDateIdB:string 
  @Prop({type:String})
  sectionIdB:string 
  @Prop({type:Boolean,default:false})
  inLanding:boolean 
  @Prop({type:Boolean,default:false})
  inCarnivalPage:boolean 
  @Prop({ type: Date, default: Date.now })
  createAt: Date;
  @Prop({ type: Date })
  deleteAt: Date;
}
export const ComparesSchema = SchemaFactory.createForClass(Compares);
