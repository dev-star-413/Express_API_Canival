import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Mongoose } from 'mongoose';

export type GalleryDocument = Gallery & Document;
@Schema()
export class Gallery {
    @Prop({ required: true })
    title: string
    @Prop({ required: true })
    dateId: string
    @Prop({  })
    desc: string
    @Prop({type:[Object]})
    imgs:Array<{
        mime:String,
        path:String,
        name:String,
        _id:any,
        text: string
    }>
    @Prop({type:Boolean})
    active: boolean
    @Prop({ type: Date, default: Date.now })
    createAt: Date
    @Prop({ type: Date })
    deleteAt: Date
    @Prop({type:[Object]})
    bands:Array<{
        _id:any,
        name:String,
        slug:String,
    }>
}
export const GallerySchema = SchemaFactory.createForClass(Gallery)