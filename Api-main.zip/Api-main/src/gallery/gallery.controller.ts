import { Controller } from '@nestjs/common';

@Controller('gallery')
export class GalleryController {}
