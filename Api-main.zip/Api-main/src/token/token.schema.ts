import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type TokensDocument = Token & Document;

@Schema()
export class Token {
  @Prop({required:true,type:Object})
  userId: object;

  @Prop({required:true})
  email: string ;

  @Prop()
  token:string;
}

export const TokenSchema = SchemaFactory.createForClass(Token)