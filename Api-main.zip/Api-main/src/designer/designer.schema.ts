import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema()
export class Designer {
    @Prop({ required: true })
    name: string;
    @Prop({ type: Object })
    festival: object;
    @Prop()
    lastYear: number;
    @Prop({ type: Object })
    bands: object;
    @Prop({ type: Object })
    img: {
        name: string;
        path: string;
        mime: string;
    };
    @Prop()
    city: string;
    @Prop()
    about: string;
    @Prop()
    slug: string;
    @Prop()
    coName: string;
    @Prop({ required: true, default: Date.now })
    createAt: Date;
    @Prop()
    deleteAt: Date;
}

export type DesignerDocument = Designer & Document;
export const DesignerSchema = SchemaFactory.createForClass(Designer);