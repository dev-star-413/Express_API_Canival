import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { DesignerDocument } from './designer.schema';
import { Model } from 'mongoose';
import getConfig from 'src/config/config.service';
import { SectionDocument } from 'src/section/section.schema';
import { BandDateDocument } from 'src/band/bandDates/band-date.schema';
import { encoder } from 'src/band/bandDates/band-date.service';
const config = getConfig();
@Injectable()
export class DesignerService {
  constructor(
  @InjectModel("Designer") private designerModel: Model<DesignerDocument>,
  @InjectModel("Section") private sectionModel: Model<SectionDocument>,
  @InjectModel("BandDate") private bandDateModel: Model<BandDateDocument>) { }
  async findAll(query, sort) {
    const designers = await this.designerModel.find(query).sort(sort);
    designers.map(designer => {
      if (designer.img) {
        designer.img.path = encoder(`${getConfig().imgDomain}${getConfig().designerImages}/${designer.img.path}`);
      }
    });
    return designers;
  }

  async findOne(params): Promise<any> {
    const designer = await this.designerModel.findOne({ slug: params.slug });
    if(!designer) return{}
    if (designer && designer.img) {
      designer.img.path = encoder(`${getConfig().imgDomain}${getConfig().designerImages}/${designer.img.path}`);
    }
    var deId=designer && designer._id
    var sections:any=await this.sectionModel.find(
      {
        'designers._id':deId
      },'img bdId name average'
    ).lean()
    
    var years={} // partition sections with year
    for(let section of sections){
      if(section.img) section.img.path = encoder(config.imgDomain + config.sectionImages + '/' + section.img.path);
      const bandDate = await this.bandDateModel.findOne({_id:section.bdId},'name dateName dateId slug year')
      section.bandDate = bandDate;
      if(bandDate){
        if(!years[bandDate.year]) {
          years[bandDate.year]=[]
        }
        years[bandDate.year].push(section)
      }
    }
    return {designer, sections:years};
  }
}
