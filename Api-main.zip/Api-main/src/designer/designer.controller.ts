import { Controller, Get, Param, Query } from '@nestjs/common';
import { DesignerService } from './designer.service';

@Controller('designer')
export class DesignerController {
  constructor(private designerService: DesignerService) { }
  @Get()
  async findAll(@Query() query): Promise<any> {
    let findObj: any = {};
    let sort: any = {};
    if(query.q) {
      findObj.name = {'$regex': query.q, '$options' : 'ig'}
    }
    if(query.sort) {
      if(query.sort === "year") {
        sort = {lastYear: -1}
      } else if (query.sort === "az") {
        sort = {name: 1}
      }
    }
    return await this.designerService.findAll(findObj, sort);
  }

  @Get('/:slug')
  async findOne(@Param() params) {
    return await this.designerService.findOne(params);
  }
}