import { Module } from '@nestjs/common';
import { DesignerService } from './designer.service';
import { DesignerController } from './designer.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { DesignerSchema } from "./designer.schema";
import { SectionSchema } from 'src/section/section.schema';
import { bandDateSchema } from 'src/band/bandDates/band-date.schema';
import { DatesSchema } from 'src/dates/dates.schema';
import { AwardSchema } from 'src/award/award.schema';

@Module({
  imports: [MongooseModule.forFeature([
    { name: 'Designer', schema: DesignerSchema },
    { name: 'Section', schema: SectionSchema },
    {name:"Dates",schema:DatesSchema},
    { name: "Award", schema: AwardSchema },
    { name: "BandDate", schema: bandDateSchema }
  ])],
  controllers: [DesignerController],
  providers: [DesignerService]
})
export class DesignerModule { }
