import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose"
import { Document, Types } from 'mongoose';

export type CommentDocument = Comment & Document;
@Schema()
export class Comment {
    @Prop()
    userId: string;
    @Prop()
    name: string; // display name user
    @Prop({type:String})
    avatar: string; //  profile user
    @Prop({ trim: true })
    comment: string
    @Prop()
    collName: string // reference to collection
    @Prop()
    docID: string //reference to one document
    @Prop()
    subID: string //reference to a sub document
    @Prop()
    replyTo: string 
    @Prop()
    rate: number;
    @Prop({ type: Object })
    score: {
        design: number;
        food: number;
        service: number;
        events: number;
        parade: number;
        // noCancel: number;
        // wasPaidFor: number;
        avg: number;
    }
    @Prop({ trim: true })
    title: string;
    @Prop({ type: [Object], default: [], maxlength: 5 })
    imgs: Array<{
        name: string;
        path: string;
        mime: string;
    }>
    @Prop({ type: Boolean, default: false })
    isFeatured: boolean
    @Prop({ type: Date })
    confirmedAt: Date
    @Prop({ type: Date, default: new Date() })
    createAt: Date
    @Prop({ type: Date })
    deleteAt: Date
    @Prop({ type: Boolean })
    isOrganizer: boolean // for band collection
    @Prop({ type: [Types.ObjectId] })
    likes: [Types.ObjectId]
}
export const CommentSchema = SchemaFactory.createForClass(Comment);