import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CommentController } from './comment.controller';
import { CommentSchema } from './comment.schema';
import { CommentService } from './comment.service';
import { UserSchema } from 'src/user/user.schema';
import { BlogSchema } from 'src/blog/blog.schema.';
import { SectionSchema } from 'src/section/section.schema';
import { AwardSchema } from 'src/award/award.schema';
import { bandDateSchema } from 'src/band/bandDates/band-date.schema';
import { ServicesModule } from 'src/services/services.module';

@Module({
  providers: [CommentService],
  controllers: [CommentController],
  imports: [
    ServicesModule,
    MongooseModule.forFeature([
      { name: 'Comment', schema: CommentSchema },
      { name: 'User', schema: UserSchema },
      { name: 'Blog', schema: BlogSchema },
      { name: 'Section', schema: SectionSchema },
      { name: 'Award', schema: AwardSchema },
      { name: 'BandDate', schema: bandDateSchema },
    ]),
  ],
})
export class CommentModule { }
