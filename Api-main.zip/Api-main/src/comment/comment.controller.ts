import { Body, Controller, Get, Param, Post, Put, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import { CreateCommentDTO } from './comment.create.dto';
import { CommentService } from './comment.service';

@Controller('comment')
export class CommentController {
    constructor(private commentService: CommentService) { }
    @Post("/")
    async create(@Body() body: CreateCommentDTO, @Res() res: Response): Promise<any> {
        res.json(await this.commentService.create(body, res.locals.userId))
    }
    @Get()
    async getAll(@Res() res: Response, @Query() query): Promise<any> {
        try {
            return res.json(await this.commentService.getAll(res.locals.userId, query));
        } catch (error) {
            console.error(error);
        }
    }
    @Get('/:id')
    async get(@Res() res: Response, @Param() param): Promise<any> {
        try {
            return res.json(await this.commentService.get(res.locals.userId, param));
        } catch (error) {
            console.error(error)
        }
    }
    @Put("/:id/like")
    async like(@Res() res: Response, @Param("id") id: string): Promise<any> {
      const userID = res.locals.userId;
      console.log(id, userID)
      await this.commentService.updateByID(id, {$push: {likes: userID}})
      return res.json({code: 0, data: true})
    }
    @Put("/:id/dislike")
    async dislike(@Res() res: Response, @Param("id") id: string): Promise<any> {
      const userID = res.locals.userId;
      await this.commentService.updateByID(id, {$pull: {likes: userID}})
      return res.json({code: 0, data: true})
    }
}
