import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, UpdateQuery, Types } from 'mongoose';
import { CommentDocument } from './comment.schema';
import { UserDocument } from 'src/user/user.schema';
import { BlogDocument } from 'src/blog/blog.schema.';
import { SectionDocument } from 'src/section/section.schema';
import { AwardDocument } from 'src/award/award.schema';
import { BandDocument } from 'src/band/band.schema';
import getConfig from 'src/config/config.service';
import { join } from 'path';
import { writeFile, constants } from 'fs';
const util = require("util");
import { access } from 'fs/promises';
import { FunctionsService } from 'src/services/functions.service';
const asyncWriteFile = util.promisify(writeFile);
const imagesPrefix = 'commentImages';
const profilesPrefix='profiles'
const config = getConfig()

@Injectable()
export class CommentService {
  constructor(
    @InjectModel('Comment') private CommentModel: Model<CommentDocument>,
    @InjectModel('User') private UserModel: Model<UserDocument>,
    @InjectModel('Blog') private BlogModel: Model<BlogDocument>,
    @InjectModel('Section') private SectionModel: Model<SectionDocument>,
    @InjectModel('Award') private awardModel: Model<AwardDocument>,
    @InjectModel('BandDate') private bandDateModel: Model<BandDocument>,
    private functions: FunctionsService,
  ) { }
  async create(body, user): Promise<any> {
    try {
      // add comment to the database
      var { collName, docID, subID, comment, pId, rate, imgs, replyTo } = body;
      if (!collName || !docID) return { code: -2, msg: 'CollName and DocId are required' };
      if (!user) return { code: -3, msg: 'No user found with this data' };
      user = await this.UserModel.findById(user, 'id dName img pic organizeBand');
      var avatar=(user.img && user.img.path )?`${user.img && user.img.path}`:user.pic

      let data = {
        comment,
        pId: pId,
        userId: user.id,
        name: user.dName,
        collName,
        rate,
        docID,
        subID,
        avatar,
        replyTo
      };
      const newComment = collName !== 'band' && await this.CommentModel.create(data);
      switch (collName) {
        case 'blog':
        let num=await this.CommentModel.find({collName:"blog", docID,replyTo:null}).count()
          await this.BlogModel.updateOne(
            { _id: docID },
            {$set: {commentC:num}}
          );
          break;
        case 'section':
          // let section = await this.SectionModel.findById(docID, "count");
          let count=await this.CommentModel.find({collName: 'section', docID, replyTo: null}).count()
          await this.SectionModel.updateOne(
            { _id: docID },
            {
              $set: { commentC:count }
            });
          break;
        case 'award':
          const { index } = body;
          const award = await this.awardModel.findById(docID, "_id cats");
          let categories = award.cats;
          const awardComments = categories[index].comments;
          if (pId) {
            const indexOfComment = awardComments
              .map(function (com) {
                return com.id;
              })
              .indexOf(pId);
            awardComments.splice(indexOfComment, 0, {
              id: newComment.id,
              pId: pId,
              userId: newComment.userId,
              name: newComment.name,
              comment: newComment.comment,
              createAt: newComment.createAt,
            });
          } else {
            awardComments.push({
              id: newComment.id,
              pId: pId,
              userId: user.id,
              name: user.dName,
              comment: comment,
              createAt: newComment.createAt,
            });
          }
          categories[index].comments = awardComments;
          await this.awardModel.updateOne({ _id: docID }, { cats: categories });
          break;
        case 'band':
          const bandDateId = body.bdId || body.docID;
          let bandDate: any = await this.bandDateModel.findById(bandDateId, "sumOfReviews bandId commentC");
          let bandId=bandDate.bandId
          let isOrganizer=(user.organizeBand &&user.organizeBand.isVerify && user.organizeBand._id==bandId)?true:false
          body = { ...body, userId: user._id, name: user.dName, docID: bandDateId }
          let createObj: any = {
            userId: user.id,
            name: user.dName,
            comment: body.comment,
            collName: body.collName,
            docID: bandDateId,
            score: body.score,
            title: body.title,
            subID,
            replyTo,
            isOrganizer
          }
          if(imgs) {
            createObj.imgs = await this.functions.saveFiles(imgs, imagesPrefix);
          }
          let newReview = await this.CommentModel.create({...createObj,avatar});
          if (newReview.imgs) {
            for (let image of newReview.imgs) {
              if (image.path) {
                image.path = `${config.imgDomain}${config[imagesPrefix]}/${image.path}`;
              }
            }
          }
          if(newReview.avatar && !newReview.avatar.startsWith("https://")) newReview.avatar=`${config.imgDomain}${config[profilesPrefix]}/${newReview.avatar}`
          const countOfComments = await this.CommentModel.find({ collName: 'band', docID: bandDateId, replyTo: null }).count();
          let sumOfReviews = bandDate.sumOfReviews || 0;
          if(newReview.score && newReview.score.avg) {
            let avg=Number(newReview.score.avg)
            sumOfReviews += avg
          }
          const averageReview = (sumOfReviews / countOfComments).toFixed(2);
          await this.bandDateModel.updateOne(
            { _id: bandDateId }, 
            { 
              avgScore: averageReview, 
              sumOfReviews, 
              commentC: bandDate.commentC ? bandDate.commentC+1: 1 
            }
          );
          return { code: 0, newReview, averageReview, data: newReview };
     
        default:
          break;
      }
      if(newComment.avatar && !newComment.avatar.startsWith("https://") ) newComment.avatar=`${config.imgDomain}${config[profilesPrefix]}/${newComment.avatar}`
      return newComment;
    } catch (err) {
      console.log(err)
      return { code: -1, msg: 'Error occured while updating comment document.' };
    }
  }
  async get(userID: string, params): Promise<any> {
    try {
      // filter by id
      let find= await this.CommentModel.findById(params.id).lean();
      if(find && find.avatar && !find.avatar.startsWith("https://")) find.avatar=`${config.imgDomain}${config[profilesPrefix]}/${find.avatar}`
      if(find.likes && Array.isArray(find.likes)) {
        if(userID) {
          find["likedByMe"] = Boolean(find.likes.find(item => item.toString() === userID))
        } 

        find["likeCount"] = find.likes.length
        delete find.likes;
      }
    } catch (error) {
      throw error;
    }
  }
  async getAll(userID: string, params): Promise<any> {
    let { collName, docID } = params;
    var comments:any = await this.CommentModel.find({
      collName,
      docID,
      // confirmedAt: { $exists: true },
    });
    comments=comments.map((com)=>{
      com = com.toObject()    
      if(com.avatar && !com.avatar.startsWith("https://") ) com.avatar=`${config.imgDomain}${config[profilesPrefix]}/${com.avatar}`
      if(com.likes && Array.isArray(com.likes)) {
        if(userID) {
          com.likedByMe = Boolean(com.likes.find(item => item.toString() === userID))
        } 
        com.likeCount = com.likes.length
        delete com.likes;
      }
      return com
    })
    return comments;
  }
  async updateByID(id: string, updateObj: UpdateQuery<CommentDocument>) {
    return await this.CommentModel.updateOne({_id: Types.ObjectId(id)}, updateObj);
  }
}