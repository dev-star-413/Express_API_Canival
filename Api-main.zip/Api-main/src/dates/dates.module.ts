import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DatesSchema } from './dates.schema';
import { DatesController } from './dates.controller';
import { DatesService } from './dates.service';
import { FestivalSchema } from 'src/festival/festival.schema';
import { citySchema } from 'src/city/city.schema';
import { BlogSchema } from 'src/blog/blog.schema.';
import { EventSchema } from 'src/event/event.schema';
import { AwardSchema } from 'src/award/award.schema';
import { bandDateSchema } from 'src/band/bandDates/band-date.schema';
import { NewsSchema } from 'src/news/news.schema';
import { ComparesSchema } from 'src/compares/compares.schema';
import { SectionSchema } from 'src/section/section.schema';
import { GallerySchema } from 'src/gallery/gallery.schema';
import { CommentSchema } from 'src/comment/comment.schema';

@Module({
    imports:[MongooseModule.forFeature([
        {name:"Dates",schema:DatesSchema},
        { name: 'Festival', schema: FestivalSchema},
        { name: 'City', schema: citySchema},
        { name: 'Event', schema: EventSchema},
        { name: 'Blog', schema: BlogSchema},
        { name: 'BandDate', schema: bandDateSchema},
        {name:"Award",schema:AwardSchema},
        { name:'News', schema: NewsSchema },
        { name:'Compares', schema: ComparesSchema },
        { name: "Section", schema: SectionSchema },
        { name: "Gallery", schema: GallerySchema },
        { name: "Comment", schema: CommentSchema },

    ])],
    exports:[MongooseModule.forFeature([{name:"Dates",schema:DatesSchema}])],
    controllers: [DatesController],
    providers: [DatesService]
})
export class DatesModule {}
