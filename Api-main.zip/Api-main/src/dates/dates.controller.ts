import { Controller, Get, HttpStatus, Param, Query, Res } from '@nestjs/common';
import { DatesService } from './dates.service';

@Controller('dates')
export class DatesController {
  constructor(private readonly dateService: DatesService) {}

  @Get('/year/:year')
  async getByYear(@Param() params): Promise<any> {
    var result = await this.dateService.getByYear(params);
    return result;
  }
  @Get('/festivals')
  async getFestivals(@Query() query): Promise<any> {
    return await this.dateService.getFestivals(query);
  }
  @Get('/festivalLastYear/:festival')
  async getLastYearByFestival(@Param() params): Promise<any> {
    var result = await this.dateService.getLastYearByFestival(params);
    return result;
  }
  @Get('/festival/:slug')
  async getBySlug(@Param() params): Promise<any> {
    var result = await this.dateService.getBySlug(params);
    return result;
  }
  @Get('/pastYears/:slug')
  async getPastYearsById(@Param() params): Promise<any> {
    var result = await this.dateService.getPastYearsById(params);
    return result;
  }
  @Get('/landing')
  async getDatesLanding(@Param() params): Promise<any> {
    var result = await this.dateService.getLanding(params);
    return result;
  }
  // @Get('/search/name')
  // async searchCarnival(@Query() param):Promise<any>{
  //   return await this.dateService.search(param)
  // }
}
