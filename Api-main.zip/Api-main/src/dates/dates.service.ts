import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { BandDateDocument } from 'src/band/bandDates/band-date.schema';
import { BlogDocument } from 'src/blog/blog.schema.';
import { CityDocument } from 'src/city/city.schema';
import { EventDocument } from 'src/event/event.schema';
import { AwardDocument } from 'src/award/award.schema';
import { FestivalDocument } from 'src/festival/festival.schema';
import { DateDocument } from './dates.schema';
import getConfig from "src/config/config.service";
import { NewsDocument } from 'src/news/news.schema';
import { ComparesDocument } from 'src/compares/compares.schema';
import { SectionDocument } from 'src/section/section.schema';
import { encoder } from 'src/band/bandDates/band-date.service';
import { GalleryDocument } from 'src/gallery/gallery.schema';
import { CommentDocument } from 'src/comment/comment.schema';
const config = getConfig();

@Injectable()
export class DatesService {
  constructor(
    @InjectModel('Festival') private festivalModel: Model<FestivalDocument>,
    @InjectModel('Dates') private DatesModel: Model<DateDocument>,
    @InjectModel('City') private CityModel: Model<CityDocument>,
    @InjectModel('Blog') private BlogModel: Model<BlogDocument>,
    @InjectModel('BandDate') private BandDateModel: Model<BandDateDocument>,
    @InjectModel('Event') private EventModel: Model<EventDocument>,
    @InjectModel('Award') private AwardModule: Model<AwardDocument>,
    @InjectModel('News') private NewsModel: Model<NewsDocument>,
    @InjectModel('Compares') private ComparesModel: Model<ComparesDocument>,
    @InjectModel("Section") private sectionModel: Model<SectionDocument>,
    @InjectModel("Gallery") private galleryModel: Model<GalleryDocument>,
    @InjectModel("Comment") private commentModel: Model<CommentDocument>

  ) { }
  async getByYear(param): Promise<any> {
    // FIXME: ERROR here
    var { year } = param;
    if (!year) return { code: -1, msg: 'not found year', data: {} };
    // start date
    var dates = this.DatesModel.find(
      {
        year: year,
      },
      'slug festival desc img year city bestS',
    );
    dates.map((fes: any) => {
      fes.img = generateImagePath(fes.img);
      fes.pImg = generateImagePath(fes.pImg);
    });
    return { code: 0, msg: 'success', data: dates };
  }
  async getFestivals(param): Promise<any> {
    try {
      var year = param.year
      const years = await this.DatesModel.find({ canceled: false }).distinct(
        'year',
      );
      let festivals: any;
      var query: any = {
        canceled: false,
        bestE: { $gte: new Date() }
      }
      var all = []
      var regions: any = new Set()
      if (years.length > 0) {
        if (year != "upcoming") {
          query = {
            canceled: false,
            year: year
          }
        }
        festivals = await this.DatesModel.find(query,
          'slug festival desc img pImg year city bestS paradeS',
        ).sort([
          ['top', -1],
          ['bestS', 1]
        ]);

        for (var fes of festivals) {
          fes = fes.toObject();
          fes['img'] = generateImagePath(fes.img)
          fes['pImg'] = generateImagePath(fes.pImg)
          fes.bestS = moment(fes.bestS).utc().format('MMMM Do YYYY, H:mm');
          fes.paradeS = moment(fes.paradeS).utc().format('MMMM Do YYYY, H:mm');
          var city;
          if (fes.city) {
            city = await this.CityModel.findOne({ _id: fes.city });
            var data: any = {
              region: city && city.region,
              cityName: city && city.name,
              cityCode: city && city.code,
              country: city && city.country
            }
            regions.add(city && city.region)
          }
          data = { ...data, ...fes }
          all.push(data)
        }
      }
      regions = Array.from(regions);
      regions = regions.sort()
      return { years, festivals: all, regions: regions };
    } catch (error) {
      console.error(error);
      return { code: -1, msg: 'Error occurred while getting festivals' };
    }
  }
  async getByFestival(param): Promise<any> {
    var { id, slug } = param;
    if (!slug) return { code: -1, msg: 'something is wrong' };
    var date = await this.DatesModel.find({ 'festival.slug': slug });
    return { code: 0, msg: 'Success', data: date };
  }
  async getLastYearByFestival(param): Promise<any> {
    var id = param.festival;
    if (!id) return { code: -1, msg: 'something is wrong' };
    var dates = await this.DatesModel.find(
      {
        'festival.id': Types.ObjectId(id),
      }).sort({"bestS": 1})
      if(!dates[0]) return { code: 0, msg: 'Success', data: {} };
    let data = await this.getBySlug(dates.pop());
    return { code: 0, msg: 'Success', data: data };
  }
  async getPastYearsById (param): Promise<any> {
    var id = param.slug;
    if (!id) return { code: -1, msg: "Not found id" };
    var festival = await this.festivalModel.findById(id);
    if (!festival) return { code: -1, msg: "Not Found Festival", data: [] };
    var pastDates = await this.DatesModel.find({
      "festival.id": Types.ObjectId(festival.id),
      $or: [
        {
          bestE: { $lt: new Date() }
        },
        {
          paradeE: { $lt: new Date() }
        }
      ]
    }, "festival year").sort({"year":-1}).lean();
    pastDates = await Promise.all(pastDates.map(async p => {
      p.bands = await this.BandDateModel.find({ dateId: p._id });
      return p;
    }));
    return { code: 0, msg: "Success", data: pastDates };
  }
  async getBySlug(param): Promise<any> {
    var slug = param.slug;
    if (!slug) return { code: -1, msg: 'Not found slug' };
    var dates = await this.DatesModel.find({ slug });
    if (!dates || !dates[0])
      return { code: -1, msg: 'Not Found Festival', data: [] };

    let festivalId = dates[0] && dates[0].festival && dates[0].festival['id']
    var events: any = await this.EventModel.find({ dId: dates[0]._id }).sort('sDate');
    var awards: any = await this.AwardModule.find({ dId: dates[0]._id });
    var bands: any = await this.BandDateModel.find({ dateId: dates[0]._id });
    var compares: any = await this.ComparesModel.find({
      inCarnivalPage: true,
      dateIdA: dates[0]._id,
      dateIdB: dates[0]._id
    }).sort({ createAt: -1 })
    var galleries:any=await this.galleryModel.find({dateId:dates[0]._id})

    for(let gallery of galleries){
      gallery=gallery
      var imgs:any=gallery.imgs
      for(let img of imgs){
        let {mime, path}=img
        let newPath=(mime.includes('video'))? encoder('localhost:3000'+ config.videos + '/' + path):
        encoder(config.imgDomain + config.galleryImages + '/' + path)
        img.path=newPath
      }
    }
    var cBands = []
    if (compares && compares[0]) {
      for (var c of compares) {
        let bandA: any = await this.BandDateModel.findById(c.bandDateIdA, 'name slug mainImg')
        bandA = bandA.toObject()
        var bandImgs: any = bandA.mainImg || {};
        bandImgs.path =
            encoder(config.imgDomain + config.bandImages + '/' + bandImgs.path);
        
        bandA.mainImg = bandImgs
        if (c.sectionIdA) {
          let section: any = await this.sectionModel.findById(c.sectionIdA, 'img name')
          section = section.toObject()
          if (section.img && section.img.path) section.img.path = config.imgDomain + config.sectionImages + '/' + section.img.path;
          bandA.section = section
        }
        //----second band
        let bandB: any = await this.BandDateModel.findById(c.bandDateIdB, 'name slug mainImg')
        bandB = bandB.toObject()
        var bandImgs: any = bandB.mainImg || {};
          bandImgs.path =
            encoder(config.imgDomain + config.bandImages + '/' + bandImgs.path);
        
        bandB.mainImg = bandImgs
        if (c.sectionIdB) {
          let section: any = await this.sectionModel.findById(c.sectionIdB, 'img name')
          section = section.toObject()
          if (section.img && section.img.path) section.img.path = encoder(config.imgDomain + config.sectionImages + '/' + section.img.path);
          bandB.section = section
        }
        cBands.push([bandA, bandB])
      }
    }
    var festival = await this.festivalModel.findById(festivalId);
    if (!festival) return new Error('Error Message: Festival Not Found')
    var pastDates = await this.DatesModel.find({
      'festival.id': Types.ObjectId(festival.id),
      $or: [
        {
          bestE: { $lt: new Date() },
        },
        {
          paradeE: { $lt: new Date() },
        },
      ],
    }, 'festival year slug').sort('year')

    var blogs = await this.BlogModel.find({ 'festivals._id': festivalId }, 'cats title slug')
    var news = await this.NewsModel.find({ dId: dates[0]._id }, 'dId title')
    var thisDate: any = dates[0].toObject();
    pastDates = pastDates.filter(index => index._id.toString() != thisDate._id.toString())
    var city;
    if(thisDate.city)
     city= await this.CityModel.findOne({ _id: thisDate.city });
    if (city) {
      thisDate['tz'] = city && city.tz;
      thisDate['cityCode'] = city && city.code;
      thisDate['cityLatlng']=city && city.latlng
    }
    var now = moment(new Date()).format("YYYY-MM-DD");
    var pS = moment(thisDate.paradeS).format("YYYY-MM-DD");
    var EndDate = moment(thisDate.bestE);
    // diff day calculate by time, Loss limit is 1 day   ex:(today 13:00 - tomarrow 8:00  diffDay=0)
    var diffDays = moment(pS,"YYYY-MM-DD").diff(moment(now,"YYYY-MM-DD"), 'days') ;
    // ------
    var diffDaysEnd = EndDate.diff(now, 'days');
    if(thisDate.paradeS)
      thisDate.paradeS = moment(thisDate.paradeS).utc().format('ddd, MMM D, YYYY @ H:mm A');
    if(thisDate.paradeE)
      thisDate.paradeE = moment(thisDate.paradeE).utc().format('ddd, MMM D, YYYY @ H:mm A');
    if(thisDate.jouvertStartDate)
      thisDate.jouvertStartDate = moment(thisDate.jouvertStartDate).utc().format('ddd, MMM D, YYYY @ H:mm A');
    if(thisDate.jouvertEndDate )
      thisDate.jouvertEndDate = moment(thisDate.jouvertEndDate).utc().format('ddd, MMM D, YYYY @ H:mm A');
    if(thisDate.bestS)
      thisDate.bestS = moment(thisDate.bestS).utc().format('MMM Do');
    if(thisDate.bestE)
      thisDate.bestE = moment(thisDate.bestE).utc().format('MMM Do YYYY');
    var img = thisDate.img || {};
    let pImg = thisDate.pImg || {}
    let jImg = thisDate.jImg || {}
    if(img && img.path)img.path = encoder((config.imgDomain + config.dateImages + '/') + (img && img.path));
    thisDate.img = img;
    if(pImg && pImg.path) pImg.path = encoder((config.imgDomain + config.dateImages + '/') + (pImg && pImg.path))
    if(thisDate.childrenImage && thisDate.childrenImage) thisDate.childrenImage.path = encoder((config.imgDomain + config.dateImages + '/') + (thisDate.childrenImage && thisDate.childrenImage.path))

    if(jImg && jImg.path) jImg.path = encoder((config.imgDomain + config.dateImages + '/') + (jImg &&jImg.path))

    thisDate.pImg = pImg;
    events = events.map((index) => {
      index = index.toObject();
      let imgs = index.imgs;
      if (imgs && imgs[0])
        imgs[0].path = encoder(config.imgDomain + config.eventImages + '/' + imgs[0].path);
      index.sDate = moment(index.sDate).utc().format('ddd, MMM D, YYYY');
      return index;
    });
    bands = bands.map((index) => {
      index = index.toObject();
      if(index.lDate) index.lDate = moment(index.lDate).utc().format('ddd, MMM D, YYYY');
      if(index.rdDate) index.rdDate = moment(index.rdDate).utc().format('ddd, MMM D, YYYY');
      let mainImg = index.mainImg;
      if (mainImg && mainImg.path) {
        mainImg.path = encoder(config.imgDomain + config.bandImages + '/' + mainImg.path);
      }
      index.sDate = moment(index.sDate).utc().format('ddd, MMM D, YYYY, h:mm');
      return index;
    });

    if(thisDate.childrenStartD) thisDate.childrenStartD = moment(thisDate.childrenStartD).utc().format('ddd, MMM D, YYYY');
    if(thisDate.childrenEndD) thisDate.childrenEndD = moment(thisDate.childrenEndD).utc().format('ddd, MMM D, YYYY');

    const yearOtherFestivals = await this.DatesModel.find({year: dates[0].year}, {id: 1, slug: 1, festival: 1, year: 1, city: 1});
    let yearOtherFestivalsResult = [];
    for(let yearOtherF of yearOtherFestivals) {
      if(yearOtherF.id === dates[0].id) {
        continue;
      }
      
      let yearOtherFsObj: any = yearOtherF.toObject()
      var thisCity;
      if(yearOtherF.city)
        thisCity = await this.CityModel.findById(yearOtherF.city)
      if(thisCity) {
        yearOtherFsObj.region = thisCity.region;
      }
      yearOtherF = yearOtherFsObj;
      yearOtherFestivalsResult.push(yearOtherF)
    }

    thisDate['dateEvents'] = events;
    thisDate['nDaysToStartP'] = diffDays;
    thisDate['diffDaysEnd'] = diffDaysEnd;
    thisDate['bands'] = bands;
    thisDate['compares'] = cBands;
    thisDate['blogs'] = blogs;
    thisDate['news'] = news
    thisDate['history'] = festival && festival.history;
    thisDate['about'] = festival && festival.desc;
    // thisDate['heading'] = (diffDaysEnd >= 0) ? festival && festival.heading : null
    thisDate['keyWord'] = festival && festival.keyWord
    thisDate['festivalMeta'] = festival && festival.meta
    thisDate['awards'] = awards
    thisDate['pastDates'] = pastDates
    thisDate['galleries']=galleries
    thisDate.yearOtherFestivals = yearOtherFestivalsResult

    // var blogs=await this.BlogModel.find({})
    return { code: 0, msg: 'Success', data: thisDate };
  }
  async getLanding(param): Promise<any> {
    var festivals =await this.festivalModel.find({lPage:true}).sort([['onTop', -1]]).limit(6)
    var dates = []
    for(let festival of festivals){
      let date=await this.DatesModel.find({
        // lPage: true,
        'festival.id':festival._id,
        canceled: false,
      }).sort([['bestS', -1]]).limit(1);
      if(date && date[0]) {
        date[0].festival.slug = festival.slug;
        dates.push(date[0]);
      }
    }
    if(!dates[0]){
      dates = await this.DatesModel.find({
        // lPage: true,
        canceled: false,
        $or: [
          {
            // bestS: { $gte: new Date() },
          },
          {
            // paradeS: { $gte: new Date() },
          },
        ],
      })
        .sort([
          ['bestS', -1],
        ])
        .limit(6);
    }
    var compares = await this.ComparesModel.find({ inLanding: true }).sort({ createAt: -1 })
    var cBands = []
    if (compares && compares[0]) {
      for (var c of compares) {
        let bandA: any = await this.BandDateModel.findById(c.bandDateIdA, 'name slug mainImg')
        bandA = bandA.toObject()
        var bandImgs: any = bandA.mainImg || {};
        bandImgs.path =encoder(config.imgDomain + config.bandImages + '/' + bandImgs.path);
        
        bandA.mainImg = bandImgs
        if (c.sectionIdA) {
          let section: any = await this.sectionModel.findById(c.sectionIdA, 'img name')
          section = section.toObject()
          if (section.img && section.img.path) section.img.path = encoder(config.imgDomain + config.sectionImages + '/' + section.img.path);
          bandA.section = section
        }
        //----second band
        let bandB: any = await this.BandDateModel.findById(c.bandDateIdB, 'name slug mainImg')
        bandB = bandB.toObject()
        var bandImgs: any = bandB.mainImg || [];
          bandImgs.path =
            encoder(config.imgDomain + config.bandImages + '/' + bandImgs.path);
        
        bandB.mainImg = bandImgs
        if (c.sectionIdB) {
          let section: any = await this.sectionModel.findById(c.sectionIdB, 'img name')
          section = section.toObject()
          if (section.img && section.img.path) section.img.path = encoder(config.imgDomain + config.sectionImages + '/' + section.img.path);
          bandB.section = section
        }
        cBands.push([bandA, bandB])
      }
    }
    var all: any = await Promise.all(
      dates.map(async (index) => {
        try {
          var data: any = index.toObject();
          data.paradeS = moment(index.paradeS).utc().format(
            'ddd, MMM D YYYY',
          );
          data.paradeE = moment(index.paradeE).utc().format(
            'ddd, MMM D YYYY',
          );
          data.bestS = moment(index.bestS).utc().format('ddd, MMM D YYYY');
          data.bestE = moment(index.bestE).utc().format('ddd, MMM D YYYY');
          var city;
          if(index.city)
            city = await this.CityModel.findById(index.city);
          if (city) {
            data['tz'] = city && city.tz;
            data['cityCode'] = city && city.code;
            data['cityName'] = city && city.name
          }
          var dateImgs = data.img || {};
          dateImgs.path =
            encoder(config.imgDomain + config.dateImages + '/' + dateImgs.path);
          data.img = dateImgs;
          return data;
        } catch (error) {
          console.log(error);
          return index.toObject();
        }
      })
      );
      var comments=await this.commentModel.find({collName:"band",replyTo:{$exists:false},comment:{$exists:true},'score.avg':{$exists:true}}).sort({createAt:-1}).limit(10)
      var reviews =[]
      for (let rev of comments){
        let bandDate=await this.BandDateModel.findById(rev.docID,'name dateName year')
        let data={
          title:rev.title,
          comment:rev.comment,
          avatar:rev.avatar,
          band:bandDate && bandDate.name,
          festival:bandDate && bandDate.dateName,
          year:bandDate && bandDate.year,
          score:rev.score
        }
        reviews.push(data)
      }
    return { dates: all, compareBands: cBands ,reviews};
  }
  // async search(param):Promise<any>{
  //   try {
  //     var searchQ=new RegExp(`${param.q}`,'i')
  //     var carnivals =await this.DatesModel.find({
  //       'festival.name':{
  //           $regex:searchQ
  //       }},'festival slug year').lean()
  //       return {code:0,msg:"Success",data:{carnivals}}
  //
  //   } catch (error) {
  //     console.log(error)
  //     return {code:-1,msg:"Erro",data:{}}
  //   }
  // }
}

function generateImagePath(img: any) {
  if (img) {
    img.path = encoder(`${config.imgDomain}${config.dateImages}/${img.path}`);
  }
  return img
}
