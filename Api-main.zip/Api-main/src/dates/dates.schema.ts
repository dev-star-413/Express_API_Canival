import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
export type DateDocument = Dates & Document;
@Schema()
export class Dates {
  @Prop({ type: String, unique: true, required: true })
  slug: string;
  @Prop({ type: Object })
  festival: {
    id: string;
    name: string;
  };
  @Prop({ type: Date })
  bestS: Date;
  @Prop({ type: Date })
  bestE: Date;
  @Prop({ type: Date })
  paradeS: Date;
  @Prop({ type: Date })
  paradeE: Date;
  @Prop({ type: Object })
  img: object;
  @Prop({})
  price: string;
  @Prop({ trim: true })
  theme: string;
  @Prop({ trim: true })
  desc: string; // about
  @Prop({ type: Boolean, default: false })
  canceled: Boolean;
  @Prop({ type: Number })
  year: number;
  @Prop({ type: Array })
  tsk: [string];
  @Prop({ type: Object })
  todo: object;
  @Prop({})
  city: String;
  @Prop({ type: Number })
  likeC: number;
  @Prop({ type: Number })
  commentC: number;
  @Prop({ type: Object })
  comments: object;
  @Prop({ type: Date, default: Date.now })
  createAt: Date;
  @Prop({ type: Date })
  deleteAt: Date;
  @Prop({ type: Boolean })
  lpage: boolean;
  @Prop({ type: Boolean })
  top: boolean;
  @Prop({ type: Object })
  paradeGeo: object;
  @Prop({ trim: true })
  meta: string; // about
  @Prop()
  imgTitle: string
  @Prop()
  paradeDesc: string
  //---
  @Prop({type:String})
  costume:string
  @Prop({type:String})
  event:string
  @Prop({type:String})
  result:string
  @Prop({type:String})
  review:string
  @Prop({type:String})
  guide:string // travel should know
  @Prop({type:String})
  whereToStay:string // where to stay
  @Prop({ type: Object }) // parade img
  @Prop({type:Object})
  pImg:object;
  @Prop({type:String})
  jouvert:string
  @Prop({type:String})
  jouvertAddress:string
  @Prop({type:Date})
  jouvertStartDate:Date
  @Prop({type:Date})
  jouvertEndDate:Date
  @Prop({type:Object})
  jImg:object
  @Prop({type:String})
  heading:string
  @Prop({type:String})
  intro:string

  ///
  @Prop({type:Date})
  childrenStartD:Date

  @Prop({type:Date})
  childrenEndD:Date
  @Prop({ type: Object })
  eventImg:object 
  @Prop({ type: Object })
  childrenImage:object
  @Prop({type:String})
  childrenParadeAddress:string
  @Prop({type:String})
  childrenDesc:string
  @Prop({type:String})
  paradeLocation:string
  @Prop({type:String})
  officialName:string
  @Prop({type:Boolean})
  isActive:boolean
}
export const DatesSchema = SchemaFactory.createForClass(Dates);
