import { ApiProperty } from "@nestjs/swagger";

export class CreateSection{
    @ApiProperty({
        description:'band id '
    })
    bandId:string
    @ApiProperty({
        description:'type section'
    })
    type:string
    @ApiProperty({
        description:""
    })
    line:number
    @ApiProperty({
        description:"price section"
    })
    price:number
    @ApiProperty({
        description:"if sold out, send true"
    })
    soldout:boolean
    @ApiProperty({
        description:""
    })
    purchase:object
    @ApiProperty({
        description:"styles section"
    })
    styles:object
    @ApiProperty({
        description:"images section"
    })
    imgs:object
    @ApiProperty({
        description:""
    })
    addons:object
    @ApiProperty({
        description:"slug section"
    })
    slug:object
    
}