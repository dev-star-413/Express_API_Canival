import { Module } from '@nestjs/common';
import { SectionService } from './section.service';
import { SectionController } from './section.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { SectionSchema } from './section.schema';
import { VoteSchema } from 'src/vote/vote.schema';
import { AwardSchema } from 'src/award/award.schema';

@Module({
  imports: [MongooseModule.forFeature([
    { name: "Section", schema: SectionSchema },
    { name: 'Vote', schema: VoteSchema },
    { name: "Award", schema: AwardSchema },
  ])],
  controllers: [SectionController],
  providers: [SectionService]
})
export class SectionModule { }
