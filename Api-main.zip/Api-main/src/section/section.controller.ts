import { Body, Controller, Get, Param, Post, Res } from '@nestjs/common';
import { Response } from 'express';
import { CreateSection } from './dto/create';
import { SectionService } from './section.service';

@Controller('section')
export class SectionController {
  constructor(private readonly sectionService: SectionService) { }
  @Post()
  async create(@Body() body: CreateSection): Promise<any> {
    return await this.sectionService.create(body);
  }
  @Get()
  async getAll(): Promise<any> {
    return await this.sectionService.getAll();
  }
  @Get("/getSectionDescs/:bandId")
  async getSectionDescs(@Param() params): Promise<any> {
    return await this.sectionService.getSectionDescs(params);
  }
  @Get("/getSectionDetails/:bandId")
  async getSectionDetails(@Param() params): Promise<any> {
    return await this.sectionService.getSectionDetails(params);
  }
  @Get("/like/:slug")
  async like(@Param() params) {
    return await this.sectionService.like(params);
  }
  @Post("/review/update")
  async updateReview(@Res() res: Response, @Body() body) {
    res.json(await this.sectionService.updateReviews(res.locals && res.locals.userId, body));
  }
}
