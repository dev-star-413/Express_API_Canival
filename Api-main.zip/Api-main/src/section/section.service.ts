import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AwardDocument } from 'src/award/award.schema';
import { VoteDocument } from 'src/vote/vote.schema';
import { SectionDocument } from './section.schema';

@Injectable()
export class SectionService {
    constructor(
        @InjectModel("Section") private sectionModel: Model<SectionDocument>,
        @InjectModel("Vote") private voteModel: Model<VoteDocument>,
        @InjectModel("Award") private awardModel: Model<AwardDocument>,
    ) { }
    async create(params): Promise<any> {
        try {
            let data = {
                bandId: params.bandId,
                type: params.type,
                line: params.line,
                price: params.price,
                soldout: params.soldout,
                purchase: params.purchase,
                styles: params.styles,
                imgs: params.imgs,
                addOns: params.addOns,
            }
            let newSection = await new this.sectionModel(data);
            return newSection.save();
        } catch (error) {
            return { code: -1, msg: error };
        }
    }

    async getAll(): Promise<any> {
        try {
            return await this.sectionModel.find();
        } catch (error) {
            return { code: -1, msg: error };
        }
    }

    async getSectionDescs(params): Promise<any> {
        try {
            return await this.sectionModel.find({ bandId: params.bandId }, { type: 1, line: 1, price: 1 });
        } catch (error) {
            return { code: -1, msg: error };
        }
    }

    async getSectionDetails(params): Promise<any> {
        try {
            return await this.sectionModel.find({ bandId: params.bandId });
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    async like(params): Promise<any> {
        try {
            // const blog = await this.sectionModel.findOne({ slug: params.slug });
            // await this.sectionModel.updateOne({ slug: params.slug }, { likeC: blog.likeC.valueOf() + 1 });
            // return await this.sectionModel.findOne({ slug: params.slug }, { likeC: 1 });
            return { code: -1, msg: "Like feature has been deleted for this document" };
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    async updateReviews(userId, body) {
        try {
            let { docID, rate } = body;
            rate = Number(rate);
            if (rate < 0 || rate > 5) {
                return { code: 1, msg: 'Invalid input', data: {} }
            }
            const voteExists = await this.voteModel.findOne({ docID, userId, docType: 'section' }, '_id rate');
            let section = await this.sectionModel.findById(docID, '_id average count');
            let sum = (section.count || 0) * (section.average || 0);
            if (voteExists) {
                sum -= voteExists.rate;
                section.count--;
                await voteExists.delete();
            }
            await this.voteModel.create({
                docID,
                rate,
                userId,
                docType: 'section',
            });
            const averageRate = parseFloat(((sum + rate) / (section.count + 1)).toFixed(1));
            await this.sectionModel.updateOne({ _id: docID }, { average: averageRate, count: section.count + 1 });
            return { code: 0, data: averageRate };
        } catch (error) {
            console.error(error)
            return { code: 1, msg: 'Error occurred while updating section reviews.' }
        }
    }

    async deleteHotness() {
        try {
            console.log('fsadlkjsadflk')
            await this.voteModel.deleteMany();
            await this.sectionModel.updateMany({}, { $unset: { average: 1, sum: 1 } });
            await this.awardModel.updateMany({}, { $unset: { 'cats.$[].agree': 1, 'cats.$[].disagree': 1, 'cats.$[].notsure': 1 } });
        } catch (error) {
            console.error(error);
        }
    }

}