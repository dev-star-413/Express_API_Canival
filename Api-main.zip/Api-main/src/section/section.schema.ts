import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type SectionDocument = Section & Document;
@Schema()
export class Section {
    @Prop()
    bdId: string;
    @Prop({ trim: true })
    name: string;
    @Prop()
    lDate: Date;
    @Prop()
    rdDate: Date;
    @Prop()
    price: number;
    @Prop()
    deposit: number;
    @Prop({ trim: true })
    desc: string;
    @Prop({ type: [Object] })
    designers: Array<{
        _id: string,
        name: string
    }>
    @Prop({ type: Array })
    colors: Array<string>
    @Prop({ type: Array })
    premiums: Array<string>
    @Prop({ type: Object })
    soldBy: {
        id: string;
        name: string;
    }
    @Prop()
    standard: string;
    @Prop({ type: Array, default: [] })
    types: Array<String>
    @Prop({ type: Object })
    img: {
        name: string;
        path: string;
        mime: string;
    };
    @Prop({ type: Array })
    reviews: Array<{
        id: string;
        userId: string;
        name: string;
        comment: string;
        rate: number;
        createAt: any;
    }>
    @Prop({ default: 0 })
    average: number;
    @Prop({ default: 0 })
    count: number;
    @Prop()
    starts: number;
    @Prop()
    slug: String;
    @Prop({ default: 0 })
    sold: Number;
    @Prop({ default: new Date() })
    createAt: Date;
    @Prop()
    deleteAt: Date;
    @Prop({ type: Number })
    commentC: number // comment count
    @Prop({ type: String })
    dCurrency:string // deposit currency
    @Prop({ type: String })
    pCurrency:string// price deposit
    @Prop({ type: String })
    pricingText:string// pricing text

}
export const SectionSchema = SchemaFactory.createForClass(Section);