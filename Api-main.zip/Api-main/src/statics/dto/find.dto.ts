export default class FindDto{
  slug: string;
}