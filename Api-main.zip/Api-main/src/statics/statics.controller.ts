import { Controller, Get, Query } from '@nestjs/common';
import FindDto from './dto/find.dto';
import { StaticsService } from './statics.service';

@Controller('statics')
export class StaticsController {
  constructor(private staticsService: StaticsService) { }

  @Get()
  async find(
    @Query() input: FindDto
  ): Promise<any> {
    return {code:0, data: await this.staticsService.findSlug(input.slug)};
  }
}
