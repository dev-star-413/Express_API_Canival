import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Static, StaticDocument } from './statics.schema';

@Injectable()
export class StaticsService {
  constructor(@InjectModel(Static.name) private staticModel: Model<StaticDocument>) {}

  async findSlug(slug: string) {  
    return await this.staticModel.findOne({slug, client: true});
  }
}
