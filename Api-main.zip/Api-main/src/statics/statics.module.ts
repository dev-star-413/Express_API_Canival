import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { StaticsController } from './statics.controller';
import { StaticSchema } from './statics.schema';
import { StaticsService } from './statics.service';

@Module({
  imports: [MongooseModule.forFeature([{ name: "Static", schema: StaticSchema }])],
  controllers: [StaticsController],
  providers: [StaticsService]
})
export class StaticsModule {}
