import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type StaticDocument = Static & Document;

@Schema()
export class Static {
  @Prop()
  slug: string;

  @Prop()
  title: string;

  @Prop()
  content: string;

  @Prop()
  client: boolean;

  @Prop()
  removable: boolean;

  @Prop()
  createAt: Date;

  @Prop()
  deleteAt: Date;
}

export const StaticSchema = SchemaFactory.createForClass(Static);