import { Body, Injectable, Param } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { AwardDocument } from "./award.schema";
import { Model } from 'mongoose';
import { DateDocument } from 'src/dates/dates.schema'
import getConfig from "src/config/config.service";
import { UserDocument } from 'src/user/user.schema';
import { VoteDocument } from 'src/vote/vote.schema';
import { Request, Response } from "express";
import * as md5 from "md5";
import { encoder } from 'src/band/bandDates/band-date.service';
const config = getConfig();
export const salt = 'saltissaltTHISISMYSALT';

@Injectable()
export class AwardService {
    constructor(
        @InjectModel('Award') private resultModel: Model<AwardDocument>,
        @InjectModel('Dates') private DatesModel: Model<DateDocument>,
        @InjectModel('User') private userModel: Model<UserDocument>,
        @InjectModel('Vote') private voteModel: Model<VoteDocument>,
    ) { }

    async findAll(param) {
        try {
            const awards = await this.resultModel.find({ deleteAt: { $exists: false }, canceled: false }, "name dId slug");
            const result = [];
            for (let index in awards) {
                const fDate = await this.DatesModel.findById(awards[index].dId, "festival year")
                if (fDate) {
                    let temp = {
                        name: awards[index].name, slug: awards[index].slug,
                        dateName: fDate.festival.name, year: fDate.year
                    }
                    result.push(temp);
                }
            }
            return result;
        } catch (error) {
            throw error;
        }
    }

    async findOne(@Param() param, userId) {
        try {
            const { slug } = param;
            let award = await this.resultModel.findOne({ slug: slug, deleteAt: { $exists: false }, canceled: false });
            if (!award) return { code: 0, msg: "No award found." }
            award.cats.map(category => category.positions.map(position => {
                if (position.img) {
                    position.img.path = encoder(`${config.imgDomain}${config.awardCatImages}/${position.img.path}`);
                }
            }));

            const date = await this.DatesModel.findById(award.dId, "_id festival.name year slug");
            award.fDate = { name: date.festival.name, year: date.year , slug:date.slug };
            const pastYearAwards = [];
            const pastYears = await this.resultModel.find({
                slug: { $ne: slug }, fId: award.fId, deleteAt: { $exists: false }
            }).limit(5).sort({ year: -1 });
            for (let res of pastYears) {
                if (res.dId) {
                    const fDate = await this.DatesModel.findById(res.dId, "festival year");
                    pastYearAwards.push({
                        name: fDate.festival.name,
                        year: fDate.year,
                        slug: res.slug
                    })
                }
            }
            return { award, pastYearAwards }
        } catch (error) {
            console.error(error);
            return { code: -1, msg: 'Error occurred' }
        }
    }

    async updateAwardReviews(@Body() body, req: Request, res: Response) {
        try {
            let { awardId, index, type, uniqueId } = body;
            let userId = res.locals.userId;
            if (!isValid(uniqueId)) uniqueId = '';
            if (!uniqueId) {
                let ip = req.ip;
                let agent = req.headers['user-agent'];
                let hash = md5(ip + agent);
                let validator = md5(hash + salt);
                uniqueId = hash + validator;
            }
            userId ||= uniqueId;
            let award = await this.resultModel.findById(awardId, "_id cats");
            if (!award) return { code: 0, msg: "Award does not exist." };
            const vote = await this.voteModel.findOne({ docID: awardId, docType: 'award', userId, subId: index });
            if (vote) {
                await this.voteModel.updateOne({ docID: awardId, docType: 'award', userId, subId: index }, { vote: type });
            } else {
                await this.voteModel.create({ docID: awardId, docType: 'award', userId, subId: index, vote: type });
            }
            let agree = await this.voteModel.find({ docID: awardId, docType: 'award', subId: index, vote: 'agree' }).countDocuments();
            let disagree = await this.voteModel.find({ docID: awardId, docType: 'award', subId: index, vote: 'disagree' }).countDocuments();
            let notsure = await this.voteModel.find({ docID: awardId, docType: 'award', subId: index, vote: 'notsure' }).countDocuments();
            const sum = agree + disagree + notsure;
            agree = Math.round(((agree / sum) * 100) || 0);
            disagree = Math.round(((disagree / sum) * 100) || 0);
            notsure = Math.round(((notsure / sum) * 100) || 0);
            award.cats[index].agree = agree;
            award.cats[index].disagree = disagree;
            award.cats[index].notsure = notsure;
            await this.resultModel.updateOne({ _id: awardId }, { cats: award.cats });
            return {
                code: 1,
                msg: "Review submitted successfully.",
                data: {
                    category: award.cats[index],
                    uniqueId
                }
            }
        } catch (error) {
            console.log(error);
            return { code: -1, msg: 'Error occurred' }
        }
    }
}

function isValid(input) {
    if (input) {
        let split1 = input.substring(0, 32);
        let split1Hash = md5(split1 + salt);
        let split2 = input.substring(32, 64);
        return split1Hash == split2;
    }
    return false;
}
