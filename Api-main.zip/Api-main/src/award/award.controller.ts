import { Controller, Get, Post, Body, Param, Query, Req, Res } from '@nestjs/common';
import { AwardService } from './award.service';
import { Request, Response } from "express";

@Controller('award')
export class AwardController {
  constructor(private awardService: AwardService) { }

  @Get()
  async findAll(@Query() query) {
    try {
      return await this.awardService.findAll(query);
    } catch (error) {
      return { code: -1, msg: error }
    }
  }

  @Get('/:slug')
  async findOne(@Param() param, @Res() res: Response) {
    try {
      res.json(await this.awardService.findOne(param, res.locals.userId));
    } catch (error) {
      return { code: -1, msg: error }
    }
  }

  @Post('/review/update')
  async updateAwardReviews(@Body() body, @Req() req: Request, @Res() res: Response): Promise<any> {
    res.json(await this.awardService.updateAwardReviews(body, req, res));
  }
}
