import { Module } from '@nestjs/common';
import { AwardService } from './award.service';
import { AwardController } from './award.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { AwardSchema } from './award.schema';
import { FestivalSchema } from 'src/festival/festival.schema';
import { DatesSchema } from 'src/dates/dates.schema';
import { UserSchema } from 'src/user/user.schema';
import { VoteSchema } from 'src/vote/vote.schema';

@Module({
  imports: [MongooseModule.forFeature([
    { name: "Award", schema: AwardSchema },
    { name: "Festival", schema: FestivalSchema },
    { name: "Dates", schema: DatesSchema },
    { name: 'User', schema: UserSchema },
    { name: 'Vote', schema: VoteSchema },
  ])],
  controllers: [AwardController],
  providers: [AwardService]
})
export class AwardModule { }
