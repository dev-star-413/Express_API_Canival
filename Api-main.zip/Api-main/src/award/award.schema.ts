import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

@Schema()
export class Award {
    @Prop()
    name: string
    @Prop()
    keywords: string
    @Prop({ type: Date })
    date: Date
    @Prop()
    desc: string
    @Prop({ type: [Object] })
    cats: Array<{
        title: string;
        tag: string;
        desc: string;
        positions: Array<{
            name: string;
            position: number;
            bands: string;
            img: {
                name: string;
                path: string;
                mime: string;
            }
        }>
        agree: Number;
        disagree: Number;
        notsure: Number;
        comments: Array<{
            id: string;
            pId: string;
            userId: string;
            name: string;
            comment: string;
            createAt: Date;
        }>;
    }>
    @Prop({ type: Boolean })
    canceled: boolean
    @Prop()
    cReason: string
    @Prop({ type: Object })
    city: object;
    @Prop()
    fId: string;
    @Prop()
    dId: String
    @Prop({ type: Object })
    fDate: Object;
    @Prop()
    slug: string;
    @Prop({ type: Date, default: Date.now })
    createAt: Date
    @Prop({ type: Date })
    deleteAt: Date
}

export type AwardDocument = Award & Document;
export const AwardSchema = SchemaFactory.createForClass(Award);