import generalConfig from "./general";
import { parse } from "dotenv";
import { readFileSync } from "fs";
import { ConfigDto } from "./config.dto";

let config: any = generalConfig();
try{
  const envFileConfig = parse(readFileSync(".env"));
  for (let i in envFileConfig) {
    config[i] = envFileConfig[i];
  }
} catch (err) {
  if(err.code === "ENOENT" && err.path === ".env"){
    // do nothing!
  } else {
    throw err;
  }
}

export default function getConfig(): ConfigDto {
  return config;
}
