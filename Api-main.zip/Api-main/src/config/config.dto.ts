export class ConfigDto {
  dbUrl?: string;
  defaultImages: string;
  designerImages: string;
  dateImages: string;
  eventImages: string;
  newsImages: string;
  galleryImages: string;
  tradeImages: string;
  blogImages: string;
  awardCatImages: string;
  adsImages: string;
  addOnsImages: string;
  sectionImages: string;
  lineImages: string;
  festivalImages: string;
  commentImages: string;
  bandImages: string;
  videos: string;
  domain?: string;
  sectionTypes: Array<String>;
  lineTypes: Array<String>;
  port?: number;
  adminProjectPath?: string;
  imgDomain?:string;
  webClientID?:string;
  fbID?:string;
  fbSecret?:string;
}
