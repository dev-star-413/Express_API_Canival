export default () => {
  return {
    defaultImages: "/images/defaults",
    designerImages: "/images/designers",
    dateImages: "/images/dates",
    eventImages: "/images/events",
    newsImages: "/images/news",
    galleryImages: "/images/gallery",
    tradeImages: "/images/trades",
    blogImages: "/images/blogs",
    awardCatImages: "/images/awardCats",
    adsImages: "/images/ads",
    addOnsImages: "/images/addOns",
    lineImages: "/images/lines",
    sectionImages: "/images/sections",
    festivalImages: "/images/festivals",
    commentImages: "/images/comments",
    bandImages: "/images/bands",
    videos: "/videos",
    sectionTypes: ['Mas/Costume', `J'ouvert`, 'Day2/2nd Wear', 'Others'],
    lineTypes: ["Section leader", "Ultra Front", "Frontline", "Midline", "Backline", "Male", "T Shirt", "None"],
    profiles:"/images/profiles"
  }
};
