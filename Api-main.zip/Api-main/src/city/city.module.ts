import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { citySchema } from './city.schema';

@Module({
    imports:[MongooseModule.forFeature([{name:"City",schema:citySchema}])],
    exports:[MongooseModule.forFeature([{name:"City",schema:citySchema}])]
})
export class CityModule {}
