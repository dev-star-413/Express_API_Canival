import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type CityDocument = City & Document;
@Schema()
export class City {
    @Prop()
    name: string;
    @Prop()
    code: string;
    @Prop()
    country: string;
    @Prop()
    region: string;
    @Prop()
    state: string;
    @Prop()
    tz: Number;
    @Prop({ type: Date, default: Date.now })
    createAt: Date;
    @Prop({ type: Date })
    deleteAt: Date;
    @Prop({ type: Object })
    latlng: object
    @Prop({ type: String })
    currency: string
}
export const citySchema = SchemaFactory.createForClass(City);