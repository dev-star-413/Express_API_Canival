import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { EventDocument } from './event.schema';
import getConfig from "src/config/config.service";
import { DateDocument } from 'src/dates/dates.schema';
import * as moment from "moment";
import { CityDocument } from 'src/city/city.schema';
import { UserDocument } from 'src/user/user.schema';
import { encoder } from 'src/band/bandDates/band-date.service';
import { BandDocument } from 'src/band/band.schema';
import { DesignerDocument } from 'src/designer/designer.schema';
import { CurrencyRateDocument } from 'src/currencyRate/currencyRate.schema';

const config = getConfig();

@Injectable()
export class EventService {
    constructor(
        @InjectModel('Event') private eventModel: Model<EventDocument>,
        @InjectModel('Date') private dateModel: Model<DateDocument>,
        @InjectModel('City') private cityModel: Model<CityDocument>,
        @InjectModel('User') private userModel: Model<UserDocument>,
        @InjectModel('Band') private bandModel: Model<BandDocument>,
        @InjectModel('Designer') private designerModel: Model<DesignerDocument>,
        @InjectModel('CurrencyRate') private currencyRatModele: Model<CurrencyRateDocument>,
    ) { }
    async getAll(): Promise<any> {
        try {
            const eventTypes = ['Boat/Cruise','Carnival Band Launch', 'Comedy','Fashion Show','Food/Drinks','Dance party']
            var events :any= await this.eventModel.find({}, "_id slug link name price vName dId sDate city tags types")
                .sort({ sDate: -1 });
            events=events.filter(e=>e.dId)
            const dateIds = events.map(event => {
                if(event.dId) return event.dId
            });
            const carnivals = await this.dateModel.find({ _id: dateIds }, "festival.name year");
            // const designers = await this.designerModel.find({ },'name');
            // const bands = await this.bandModel.find({ },'name');
            return { events: events, carnivals: carnivals,eventTypes
                // designers:designers,bands:bands 
            };
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    async get(params): Promise<any> {
        try {
            let event:any = await this.eventModel.findOne({ slug: params.slug });
            event=event.toObject()
            if (event) {
                if (event.imgs) {
                    for (let img of event.imgs) {
                        img.path = encoder(`${config.imgDomain}${config.eventImages}/${img.path}`);
                    }
                }
                let carnival = await this.dateModel.findById(event.dId, "festival year");
                let carnivalName;
                if (carnival) {
                    carnivalName = `${carnival.festival.name} ${carnival.year}`;
                }
                const similarEvents = await this.eventModel.find({
                    _id: { $ne: event._id },
                    imgs: { $ne: null },
                    $and: [
                        { types: {$all:event.types }}, { dId: event.dId }
                    ]
                }, "slug types name city vName sDate price imgs").limit(12);
                for (let sim of similarEvents) {
                    sim.imgs.map(img => { img.path = encoder(`${config.imgDomain}${config.eventImages}/${img.path}`) })
                }
                let city;
                if(event.city) {
                  city = await this.cityModel.findById(event.city.id, "_id name country state latlng")
                }
                let currencyRates=await this.currencyRatModele.find({})
                return { event, similarEvents, carnival: carnivalName, city,currencyRates };
            } else {
                return { event: null, code: 0, msg: "Event not found." }
            }

        } catch (error) {
            console.log(error);
            return { code: -1, msg: `An error occurred while getting ${params.slug}` };
        }
    }
    async like(params): Promise<any> {
        try {
            const blog = await this.eventModel.findOne({ slug: params.slug });
            await this.eventModel.updateOne({ slug: params.slug }, { likeC: blog.likeC.valueOf() + 1 });
            return await this.eventModel.findOne({ slug: params.slug }, { likeC: 1 });
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    async getEventByDateId(param): Promise<any> {
        try {
            let events = await this.eventModel.find({ dId: param.dId })
            return { code: 0, msg: "success", data: events }
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    async getEventFormParameters(): Promise<any> {
        try {
            const rawDates = await this.dateModel.find({ canceled: false }, "festival year");
            const rawCities = await this.cityModel.find({}, "_id name code state country");
            const dates = [];
            const cities = [];
            const countries = rawCities.map(city => city.country).filter(unique);
            rawDates.map(date => dates.push({ id: date._id, name: `${ date.festival && date.festival.name} - ${date.year}` }));
            rawCities.map(city => cities.push({ id: city._id, name: city.name, country: city.country, state: city.state }));
            return { dates, cities, countries }
        } catch (error) {
            return { code: -1, msg: "Error occurred while getting event form parameters" }
        }
    }
    async create(body,userId): Promise<any> {
        try {
            // const { userId } = body;
            const user = await this.userModel.findById(userId, "_id dName");
            if (userId) {
                let {
                    name,
                    city,
                    dId,
                    vName,
                    vAddress,
                    frequency,
                    sDate,
                    eDate,
                    mGenre,
                    type,
                    pitch,
                    price,
                    link,
                    desc,
                } = body;
                city = await this.cityModel.findById(city, "_id name");
                await this.eventModel.create({
                    name,
                    city: {
                        id: `${city.id}`,
                        name: city.name
                    },
                    dId,
                    vName,
                    vAddress,
                    frequency,
                    sDate,
                    eDate,
                    mGenre,
                    type,
                    pitch,
                    price,
                    link,
                    desc,
                    state: {
                        by: `${user.id}`,
                        name: user.dName,
                        at: new Date(),
                        confirmed: false,
                        from: null,
                        confirmedBy: null
                    }
                });
                return { code: 1, msg: "Event created successfully." }
            }
            return { code: 0, msg: 'User not found.' }
        } catch (error) {
            return { code: -1, msg: "Error occurred while creating new event." }
        }
    }
}

// https://stackoverflow.com/questions/1960473/get-all-unique-values-in-a-javascript-array-remove-duplicates
function unique(value, index, self) {
    return self.indexOf(value) === index;
}