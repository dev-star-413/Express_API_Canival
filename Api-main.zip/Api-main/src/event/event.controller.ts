import { Body, Controller, Get, Param, Post, Res } from '@nestjs/common';
import { EventService } from './event.service';

@Controller('event')
export class EventController {
    constructor(private eventService: EventService) { }
    @Get('/:slug')
    async get(@Param() param): Promise<any> {
        return await this.eventService.get(param);
    }
    @Get()
    async getAll(): Promise<any> {
        return await this.eventService.getAll();
    }
    @Post('/create')
    async create(@Body() body,@Res() res):Promise<any> {
        let userId= res.locals.userId
        return await this.eventService.create(body,userId);
    }
    @Get('/form/params')
    async getFormData(@Param() param): Promise<any> {
        return await this.eventService.getEventFormParameters();
    }
    @Get("/:slug/like")
    async like(@Param() params) {
        return await this.eventService.like(params);
    }
    @Get('/date/:dId')
    async getEventByFyId(@Param() param):Promise<any>{
        return await this.eventService.getEventByDateId(param)
    }
}
