import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { citySchema } from 'src/city/city.schema';
import { DatesSchema } from 'src/dates/dates.schema';
import { UserSchema } from 'src/user/user.schema';
import { BandSchema } from 'src/band/band.schema';
import { DesignerSchema } from 'src/designer/designer.schema';
import { EventController } from './event.controller';
import { EventSchema } from './event.schema';
import { EventService } from './event.service';
import { CurrencyRateSchema } from 'src/currencyRate/currencyRate.schema';

@Module({
    providers: [EventService],
    controllers: [EventController],
    imports: [MongooseModule.forFeature([
        { name: 'Event', schema: EventSchema },
        { name: "Date", schema: DatesSchema },
        { name: "City", schema: citySchema },
        { name: "User", schema: UserSchema },
        { name: "Band", schema: BandSchema },
        { name: "Designer", schema: DesignerSchema },
        { name: "CurrencyRate", schema: CurrencyRateSchema },
    ])],
    exports: [MongooseModule.forFeature([{ name: 'Event', schema: EventSchema }])],
})
export class EventModule { }
