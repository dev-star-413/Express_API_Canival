import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

@Schema()
export class Ad {
    @Prop()
    title: string;
    @Prop()
    header: string;
    @Prop()
    footer: string;
    @Prop({ type: Object })
    imgs: Object;
    @Prop({type:Array})
    pages:[]
    @Prop({type:Array})
    nodes:[]
    @Prop({type:Object})
    image: Object
    @Prop()
    text:String
    @Prop()
    code:String
    @Prop()
    startDate:Date
    @Prop()
    endDate:Date
    @Prop({ required: true, default: Date.now })
    createAt: Date;
    @Prop()
    deleteAt: Date;
}

export type AdDocument = Ad & Document;
export const AdSchema = SchemaFactory.createForClass(Ad);