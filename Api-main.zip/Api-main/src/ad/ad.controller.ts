import { Controller, Get,Param,Query } from '@nestjs/common';
import { AdService } from './ad.service';

@Controller('ad')
export class AdController {
  constructor(private readonly adService: AdService) { }
  @Get()
  async getAll(): Promise<any> {
    return await this.adService.getAll();
  }
  @Get("/random")
  async getRandom(@Query() query): Promise<any> {
    console.log(query)
    return await this.adService.getRandom(query);
  }
}
