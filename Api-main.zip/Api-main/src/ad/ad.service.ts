import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AdDocument } from './ad.schema';

@Injectable()
export class AdService {
    constructor(@InjectModel("Ad") private adModel: Model<AdDocument>) { }
    async getAll() {
        try {
            return await this.adModel.find();
        } catch (error) {
            return { code: -1, msg: error };
        }
    }

    async getRandom(query): Promise<any> {
        try {
            const {page,node}=query
            if(!page || !node) return {code:-1}
            var now=new Date().toISOString()
            const ads = await this.adModel.find({
                $or:[{ pages:page },{ pages:"all"}],
                nodes:node,
                startDate:{$lte:now},
                endDate:{$gte:now}
            },'code');
            var data=ads[Math.floor(Math.random() * (ads.length - 1))]
            return {code:0,msg:"success",data };
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
}
