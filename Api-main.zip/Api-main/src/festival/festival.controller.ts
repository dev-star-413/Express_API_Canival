import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { GetAboutDto } from './dto/getAboutDto';
import { GetAllDtoFestival } from './dto/getAllDto';
import { GetHistoryDtoFestival } from './dto/getHistoryDtoFestival';
import { GetOneDtoFestival } from './dto/getOneDtoFestival';
import { FestivalService } from './festival.service'
@Controller('festival')
export class FestivalController {
    constructor(private festivalService: FestivalService) { }

    @Get('/parade')
    async getParades(@Query() param): Promise<any> {
        return await this.festivalService.getParade(param)
    }
    @Get("/landing/:number")
    async getLandingPageFestivals(@Param() param): Promise<any> {
        return await this.festivalService.getAll(param)
    }
    @Get('/:slug')
    async get(@Param() param: GetOneDtoFestival): Promise<any> {
        return await this.festivalService.get(param);
    }
    @Get("/:slug/history")
    async getHistory(@Param() param: GetHistoryDtoFestival): Promise<any> {
        return await this.festivalService.getHistory(param);
    }
    @Get("/:slug/about")
    async getAbout(@Param() param: GetAboutDto): Promise<any> {
        return await this.festivalService.getAbout(param);
    }
    @Get("/:slug/like")
    async like(@Param() params) {
        // return await this.festivalService.like(params);
    }
    @Get('/trend')
    async trend(@Query() params: GetAllDtoFestival) {
        return await this.festivalService.getTrending(params)
    }
    @Get('/trend/events')
    async trendEvents(@Query() params: GetAllDtoFestival) {
        return await this.festivalService.topFestivalEvents(params)
    }
    @Get('/:fyId/tsk')
    async getTSK(@Param() param) {
        return await this.festivalService.getTSK(param)
    }
    @Get("/years/:year")
    async getfestivalsYear(@Param() Param) {
        let festivals = await this.festivalService.getFestivalsYear(Param)
        return festivals
    }
    @Get("/list/names")
    async getfestivalsNames(@Param() Param) {
        let festivals = await this.festivalService.getFestivalsNames(Param)
        return festivals
    }
    @Get("/list/years")
    async getYearsHaveFestival() {
        let festivals = await this.festivalService.getYearsHaveFestival()
        return festivals
    }
    @Get("/list/all")
    async list(){
        let data=await this.festivalService.festivals()
        return data
    }
    @Get('/search/all')
    async searchAll(@Query() param):Promise<any>{
        return await this.festivalService.searchAll(param)
    }
    @Get('/search/name')
    async searchFestival(@Query() param):Promise<any>{
        return await this.festivalService.search(param)
    }
}
