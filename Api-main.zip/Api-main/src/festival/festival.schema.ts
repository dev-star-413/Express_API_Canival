import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Mongoose } from 'mongoose';

export type FestivalDocument = Festival & Document;
@Schema()
export class Festival {
    @Prop({ required: true })
    name: string
    @Prop()
    oName: string
    @Prop()
    desc: string
    @Prop()
    history: string
    @Prop()
    type: string
    @Prop()
    lPage: boolean
    @Prop()
    active: boolean
    @Prop({ type: Object })
    features: Object
    @Prop()
    slug: string
    @Prop()
    likeC: number
    @Prop()
    commentC: number
    @Prop({ type: Object })
    imgs: Object
    @Prop({ required: true, default: Date.now })
    createAt: Date;
    @Prop()
    deleteAt: Date;
    @Prop({type:String})
    meta:string
    @Prop({type:String})
    heading:string
    @Prop({type:String})
    keyWord:string
    @Prop({type:String})
    costume:string
    @Prop({type:String})
    event:string
    @Prop({type:String})
    result:string
    @Prop({type:String})
    review:string
    @Prop({type:String})
    guide:string // travel should know
    @Prop({type:String})
    paradeDesc:string
    @Prop({type:String})
    whereToStay:string

    @Prop({ type: Object })
    mainImage: Object

    @Prop({ type: Object })
    evenImage: Object

    @Prop({ type: Object })
    paradeImage: Object

    @Prop({ type: Object })
    jouvertImage: Object

    @Prop({type:String})
    jouvert:string

    @Prop({type:Boolean})
    onTop:boolean // on Top 


    @Prop({type:String})
    paradeLocation:string
      

    // children
    @Prop({ type: Object })
    childrenImage:Object

    @Prop({type:String})
    childrenParadeAddress:string
    
    @Prop({type:String})
    childrenDesc:string
}
export const FestivalSchema = SchemaFactory.createForClass(Festival)