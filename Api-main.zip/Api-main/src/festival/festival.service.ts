import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FestivalDocument } from './festival.schema'
import { Model } from 'mongoose';
import { CityDocument } from 'src/city/city.schema';
import { FYearDocument } from 'src/festival-year/festival-year.schema';
import { DateDocument } from 'src/dates/dates.schema';
import { EventDocument } from 'src/event/event.schema';
import { GalleryDocument } from 'src/gallery/gallery.schema';
import { AwardDocument } from 'src/award/award.schema';
import { BlogDocument } from 'src/blog/blog.schema.';
import { BandDocument } from 'src/band/band.schema';
import { BandDateDocument } from 'src/band/bandDates/band-date.schema';
import { SectionDocument } from 'src/section/section.schema';
import { CommentDocument } from 'src/comment/comment.schema';
import * as moment from 'moment';
import getConfig from "src/config/config.service";
import { encoder } from 'src/band/bandDates/band-date.service';
import { ComparesDocument } from 'src/compares/compares.schema';

const config = getConfig();

@Injectable()
export class FestivalService {
    constructor(
        @InjectModel('Festival') private festivalModel: Model<FestivalDocument>,
        @InjectModel('City') private cityModel: Model<CityDocument>,
        @InjectModel('FestivalYear') private FYearModel: Model<FYearDocument>,
        @InjectModel('Dates') private DatesModel: Model<DateDocument>,
        @InjectModel('Event') private eventModel: Model<EventDocument>,
        @InjectModel('Gallery') private galleryModel: Model<GalleryDocument>,
        @InjectModel('Award') private awardModel: Model<AwardDocument>,
        @InjectModel('Blog') private blogModel: Model<BlogDocument>,
        @InjectModel('Band') private bandModel: Model<BandDocument>,
        @InjectModel('BandDate') private bandDateModel: Model<BandDateDocument>,
        @InjectModel('Section') private sectionModel: Model<SectionDocument>,
        @InjectModel('Comment') private commentModel: Model<CommentDocument>,
        @InjectModel('Compares') private compareModel: Model<ComparesDocument>,
        @InjectModel('BandDate') private BandDateModel: Model<BandDateDocument>,
        @InjectModel('Event') private EventModel: Model<EventDocument>,


    ) { }
    async getAll(params): Promise<any> {
        try {
            var n = params['number']
            n = n ? JSON.parse(n) : 5
            let festival = await this.festivalModel.find({
                deleteAt: { $exists: false }, lPage: true, active: true
            }).limit(n)
            return festival
        } catch (error) {
            throw error;
        }
    }
    async getParade(params): Promise<any> {
        try {
            let { number } = params
            if (!number) number = 5
            let n = parseInt(number);
            if (!n) n = 10
            var festival = []
            // order by parade date 
            let dates = await this.DatesModel.find({
                canceled: false,
                deleteAt: { $exists: false },
                $or: [
                    {
                        bestS: { $gte: new Date() }
                    },
                    {
                        paradeS: { $gte: new Date() }
                    }
                ]
            }).sort({ paradeS: 1 }).limit(n)
            // join dates & festivalYear and festival
            for (var d of dates) {
                let fyID = d['fyID']
                let fyear = await this.FYearModel.findById(fyID)
                let data = {}
                data["dates"] = d
                data['year'] = fyear['year']
                data['about'] = fyear['about']
                data['tsk'] = fyear['tsk']
                data['fyID'] = fyear._id // need for wishlist and like ?!
                data['city'] = fyear['city']
                let f = fyear['festival']
                let fes = await this.festivalModel.findById(f['id'])
                data = { ...data, ...fes }
                festival.push(data)
            }
            return festival
        } catch (error) {
            throw error;
        }
    }
    async get(params): Promise<any> {
        // festival data
        // events
        // gallery
        // results
        // news
        // reviews
        // guides
        // bands & bandDates
        // parade menu ? p(30) document
        try {
            var {  slug } = params
            if(!slug) return {code:1,msg:'bad request'}
            var festival = await this.festivalModel.findOne({ slug: slug }).lean();
            if (!festival) return {code:1,msg:"Not Found",data:{}}
            if(festival.jouvertImage && festival.jouvertImage.path){
                festival.jouvertImage.path=encoder((config.imgDomain + config.festivalImages + '/') + (festival.jouvertImage.path));
            }
            if(festival.paradeImage && festival.paradeImage.path){
                festival.paradeImage.path=encoder((config.imgDomain + config.festivalImages + '/') + (festival.paradeImage.path));
            }
            if(festival.childrenImage && festival.childrenImage.path){
                festival.childrenImage.path=encoder((config.imgDomain + config.festivalImages + '/') + (festival.childrenImage.path));
            }
            if(festival.mainImage && festival.mainImage.path){
                festival.mainImage.path=encoder((config.imgDomain + config.festivalImages + '/') + (festival.mainImage.path));
            }
            var now=new Date()
            var dates=await this.DatesModel.find({
                'festival.id':festival._id,
                isActive:true
                // paradeS:{$gte:now},
                // year:now.getFullYear()
            }).sort({year:-1,paradeS:1}).lean()
            if(!dates || !dates[0]){
                dates=await this.DatesModel.find({
                    'festival.id':festival._id,
                    // paradeS:{$gte:now},
                    year:now.getFullYear()
                }).sort({paradeS:1}).lean()
            }
            var thisDate=dates && dates[0]
            if(!thisDate) return {code:1,msg:"this festival have not any festival this year"}

            var today = moment(new Date()).format("YYYY-MM-DD");
            var pS = moment(thisDate.paradeS).format("YYYY-MM-DD");
            var EndDate = moment(thisDate.bestE);
            // diff day calculate by time, Loss limit is 1 day   ex:(today 13:00 - tomarrow 8:00  diffDay=0)
            var diffDays = moment(pS,"YYYY-MM-DD").diff(moment(today,"YYYY-MM-DD"), 'days') ;
            // ------
            var diffDaysEnd = EndDate.diff(today, 'days');
            thisDate.diffDaysEnd=diffDaysEnd
            thisDate.nDaysToStartP=diffDays

            if(thisDate.paradeS)
                thisDate.paradeS = moment(thisDate.paradeS).utc().format('MMM Do, YYYY, H:mm A');
            if(thisDate.paradeE)
                thisDate.paradeE = moment(thisDate.paradeE).utc().format('MMM Do, YYYY, H:mm A');
            if(thisDate.jouvertStartDate)
                thisDate.jouvertStartDate = moment(thisDate.jouvertStartDate).utc().format('MMM D, YYYY, H:mm A');
            if(thisDate.jouvertEndDate )
                thisDate.jouvertEndDate = moment(thisDate.jouvertEndDate).utc().format('MMM D, YYYY, H:mm A');
            if(thisDate.bestS)
                thisDate.bestS = moment(thisDate.bestS).utc().format('MMM Do YYYY');
            if(thisDate.bestE)
                thisDate.bestE = moment(thisDate.bestE).utc().format('MMM Do YYYY');
            if(thisDate.childrenStartD) thisDate.childrenStartD = moment(thisDate.childrenStartD).utc().format('ddd, MMM D, YYYY');
            if(thisDate.childrenEndD) thisDate.childrenEndD = moment(thisDate.childrenEndD).utc().format('ddd, MMM D, YYYY');
            var img = thisDate.img || {};
            let pImg = thisDate.pImg || {}
            let jImg = thisDate.jImg || {}
            
            if(img && img.path)img.path = encoder((config.imgDomain + config.dateImages + '/') + (img && img.path));
            thisDate.img = img;
            if(pImg && pImg.path) pImg.path = encoder((config.imgDomain + config.dateImages + '/') + (pImg && pImg.path))
            
            if(thisDate.childrenImage && thisDate.childrenImage) thisDate.childrenImage.path = encoder((config.imgDomain + config.dateImages + '/') + (thisDate.childrenImage && thisDate.childrenImage.path))
        
            if(jImg && jImg.path) jImg.path = encoder((config.imgDomain + config.dateImages + '/') + (jImg &&jImg.path))
        
            thisDate.pImg = pImg;

            if(thisDate.city){
                var city = await this.cityModel.findById(thisDate.city).lean();
                
                if (city) {
                    thisDate['tz'] = city && city.tz;
                    thisDate['cityCode'] = city && city.code;
                    thisDate['cityName'] = city && city.name
                    thisDate['cityLatlng']=city && city.latlng
                }
            }
              


            /* @bands
                Find bands of festival-date
            */
            var bands: any = await this.bandDateModel.find({ dateId: thisDate._id });
            bands = bands.map((index) => {
                index = index.toObject();
                if(index.lDate) index.lDate = moment(index.lDate).utc().format('MMM Do, YYYY, H:mm A');
                if(index.rdDate) index.rdDate = moment(index.rdDate).utc().format('MMM Do, YYYY, H:mm A');
                let { mainImg, childrenImg, childrenlImg, jImg, jlImg, costumeImg, costumeLImg } = index
                let imgs = { mainImg, childrenImg, childrenlImg, jImg, jlImg, costumeImg, costumeLImg };
                let imgsStr = ['mainImg', 'childrenImg', 'childrenlImg', 'jImg', 'jlImg', 'costumeImg', 'costumeLImg']
                for (let str of imgsStr) {
                    if (imgs[str] && imgs[str].path) {
                        imgs[str].path = encoder(config.imgDomain + config.bandImages + '/' + imgs[str].path);
                    }
                }
                index.sDate = moment(index.sDate).utc().format('ddd, MMM D, YYYY, h:mm');
                return index;
              });

            /* @News
                news of festival
            */ 
            const news=await this.blogModel.find({'festivals._id':festival._id,cats: ['News']})
            const guides=await this.blogModel.find({'festivals._id':festival._id,cats: ['Guides']})
            
            /* @Gallery
              gallery of festival-date
            */ 

            var galleries:any=await this.galleryModel.find({dateId:thisDate._id})
            for(let gallery of galleries){
                gallery=gallery
                var imgs:any=gallery.imgs
                for(let img of imgs){
                    let {mime, path}=img
                    let newPath=(mime.includes('video'))? encoder('localhost:3000'+ config.videos + '/' + path):
                    encoder(config.imgDomain + config.galleryImages + '/' + path)
                    img.path=newPath
                }
            }

            /**
            * @Award/Result award of festival-date
            */ 
            var awards: any = await this.awardModel.find({ dId: thisDate._id });

            // future festival date
            var nextDates=await this.DatesModel.find({'festival.id':festival._id,year:{$gte:now.getFullYear()}},'paradeS slug festival year').lean()
            nextDates=nextDates.map((nx)=>{
                if(nx.paradeS) nx.paradeS=moment(nx.paradeS).utc().format('ddd, MMM D, YYYY');
                return nx
            })

            /**
             * @Campare
             */
            var compares: any = await this.compareModel.find({
                inCarnivalPage: true,
                dateIdA: dates[0]._id,
                dateIdB: dates[0]._id
              }).sort({ createAt: -1 })
            var compareBands=[]
              if (compares && compares[0]) {
                for (var c of compares) {
                  let bandA: any = await this.bandDateModel.findById(c.bandDateIdA, 'name slug mainImg')
                  bandA = bandA.toObject()
                  var bandImgs: any = bandA.mainImg || {};
                  bandImgs.path =
                      encoder(config.imgDomain + config.bandImages + '/' + bandImgs.path);
                  
                  bandA.mainImg = bandImgs
                  if (c.sectionIdA) {
                    let section: any = await this.sectionModel.findById(c.sectionIdA, 'img name')
                    section = section.toObject()
                    if (section.img && section.img.path) section.img.path = config.imgDomain + config.sectionImages + '/' + section.img.path;
                    bandA.section = section
                  }
                  //----second band
                  let bandB: any = await this.bandDateModel.findById(c.bandDateIdB, 'name slug mainImg')
                  bandB = bandB.toObject()
                  var bandImgs: any = bandB.mainImg || {};
                    bandImgs.path =
                      encoder(config.imgDomain + config.bandImages + '/' + bandImgs.path);
                  
                  bandB.mainImg = bandImgs
                  if (c.sectionIdB) {
                    let section: any = await this.sectionModel.findById(c.sectionIdB, 'img name')
                    section = section.toObject()
                    if (section.img && section.img.path) section.img.path = encoder(config.imgDomain + config.sectionImages + '/' + section.img.path);
                    bandB.section = section
                  }
                  compareBands.push([bandA, bandB])
                }
              }
            
            const festivalDate=thisDate

            let events = await this.eventModel.find({ dId: thisDate._id.toString() }).lean();
            events = events.map(event => {
                for (let i in event.imgs) {
                    if (event.imgs[i] && event.imgs[i].path) {
                        event.imgs[i].path = encoder(config.imgDomain + config.eventImages + '/' + event.imgs[i].path);
                    }
                }
                if (event.sDate) event.sDate = moment(event.sDate).utc().format('ddd, MMM D, YYYY ');
                return event;
            })

            return {code:0,msg:"success",data:{festival,festivalDate,news,galleries,nextDates,awards,bands,guides,compareBands,events}}
        } catch (error) {
            return{code:-1,msg:"something is wrong."}
        }
    }
    async getHistory(params): Promise<any> {
        try {
            const festival = await this.festivalModel.findOne({ slug: params.slug });
            return festival;
        } catch (error) {
            throw error;
        }
    }
    // need test more
    // async like(params): Promise<any> {
    //     try {
    //         const blog = await this.festivalModel.findOne({ slug: params.slug });
    //         await this.festivalModel.updateOne({ slug: params.slug }, { likeC: blog.likeC.valueOf() + 1 });
    //         return await this.festivalModel.findOne({ slug: params.slug }, { likeC: 1 });
    //     } catch (error) {
    //         return { code: -1, msg: error };
    //     }
    // }
    // need test more
    async getTrending(params): Promise<any> {
        var n = JSON.parse(params['number'])
        if (!n) n = 5
        var trendingFestivals = await this.festivalModel.find({
            canceled: false,
            deleteAt: { $exists: false },
        }).sort({
            likeC: "Desc",
        })
        for (var festival of trendingFestivals) {
            let fYear = await this.FYearModel.findOne({ 'festival.id': festival._id }).sort({ year: "Desc" })
            let fDate = await this.DatesModel.find({ fyID: fYear._id })
            festival['year'] = fYear['year']
            festival['about'] = fYear['about']
            festival['tsk'] = fYear['tsk']
            festival['fyID'] = fYear._id // need for wishlist and like ?!
            festival['city'] = fYear['city']
            festival['dates'] = fDate
        }
        return trendingFestivals;
    }
    // need test more
    async topFestivalEvents(params): Promise<any> {
        try {
            var n = JSON.parse(params['number'])
            if (!n) n = 5
            var topFestival = await this.festivalModel.find({
                canceled: false,
                deleteAt: { $exists: false },
            }).sort({
                likeC: "Desc",
                createAt: "Desc"
            })
            var allEvents = []
            for (var festival of topFestival) {
                let fYear = await this.FYearModel.findOne({ 'festival.id': festival._id })
                let events = await this.eventModel.find({ fyID: fYear._id })
                allEvents = [...allEvents, ...events]
            }
            return allEvents
        } catch (error) {
            throw error
        }

    }
    async getAbout(param) {
        var { slug, fyId, year } = param
        fyId = JSON.parse(fyId)
        slug = JSON.parse(slug)
        year = JSON.parse(year)
        if (fyId) {
            let about = await this.FYearModel.findById(fyId)
            return about
        }
        let festival = await this.festivalModel.findOne({ slug })
        let abouts = await this.FYearModel.find({ 'festival.id': festival._id, year }, { about: 1 })
        return abouts
    }
    async getTSK(param) {
        let tsk = await this.FYearModel.findById(param.fyId)
        return tsk.tsk
    }
    async getFestivalsYear(param) {
        let dates: any = await this.DatesModel.find({
            year: param.year,
        },'festival').sort({'festival.name':1})
        return dates
    }
    async getFestivalsNames(param) {
        let number = param.number
        if (!number) number = 10
        let festivals = await this.festivalModel.find({
            deleteAt: { $exists: false }

        }, 'name').limit(number)
        return festivals
    }
    async searchAll(param): Promise<any> {
        let searchQ = new RegExp(`${param.q}`, "i");
        let festivals = await this.festivalModel.find({ name: { $regex: searchQ } }, "name slug").lean();
        let bandDates = await this.BandDateModel.find({ "name": { $regex: searchQ } }, "name year slug");
        let events = await this.EventModel.find({ "name": { $regex: searchQ } }, "name slug");
        return { festivals: festivals, bandDates: bandDates, events: events };
    }
    async search(param): Promise<any> {
        try {
            var searchQ = new RegExp(`${param.q}`, "i");
            var festivals = await this.festivalModel.find({
                name: {
                    $regex: searchQ
                }
            }, "name slug").lean();
            return { code: 0, msg: "Success", data: { festivals } };
        } catch (error) {
            console.log(error);
            return { code: -1, msg: "Erro", data: {} };
        }
    }
    async getYearsHaveFestival(): Promise<any> {
        var years= await this.DatesModel.distinct("year")
        years=years.sort((a,b)=>b-a)
        return years
    }
    async festivals():Promise<any>{
        try {
        var all = await this.festivalModel.find({},'name slug ').sort({name:1}).lean()
        var thisYear=new Date().getFullYear()
        var years=[thisYear-1,thisYear,thisYear+1,thisYear+2,thisYear+3]
        var fDates=await this.DatesModel.find({year:{$in:years}},'festival paradeS year isActive').sort({year:1,'festival.name':1}).lean()
        for(var fes of fDates){
            var parent=all.find((f)=>
                f._id.equals(fes.festival.id) // equals Mongoose Method
            )
            if(parent && parent.slug) fes.slug=parent.slug
            if(fes.paradeS)
            fes.paradeS=moment(fes.paradeS).utc().format('dddd, MMMM Do, YYYY');
        }
        return {code:0,msg:"success",data:fDates}
        } catch (error) {
            console.log(error)
            return {code:-1,msg:"Error",data:{}}
        }
        
    }
}
