import { ApiProperty } from "@nestjs/swagger";

export class GetAboutDto{
    @ApiProperty({
        description:'if dont send fyId. need to filter'
    })
    slug:string
    @ApiProperty({
        description:'festival_Year ip'
    })
    fyIp:string
    @ApiProperty({
        description:"if dont send fyId. need to filter festival by year"
    })
    year:number
}