import { ApiProperty } from "@nestjs/swagger";

export class GetOneDtoFestival{
    @ApiProperty({
        description:"festival slug"
    })
    slug:string;
    @ApiProperty({
        description:"festival year"
    })
    year:number
}