import { ApiProperty } from "@nestjs/swagger";

export class GetHistoryDtoFestival{
    @ApiProperty({
        description:"slug festival"
    })
    slug:string;
}