import { ApiProperty } from "@nestjs/swagger";

export class GetAllDtoFestival{
    @ApiProperty({
        description:'number of festivals received.'
    })
    number:number

}