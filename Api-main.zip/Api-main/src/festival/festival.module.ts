import { Module } from '@nestjs/common';
import { FestivalService } from './festival.service';
import { FestivalController } from './festival.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { FestivalSchema } from './festival.schema'
import { citySchema } from 'src/city/city.schema';
import { FYearSchema } from 'src/festival-year/festival-year.schema';
import { DatesSchema } from 'src/dates/dates.schema';
import { EventSchema } from 'src/event/event.schema';
import { AwardSchema } from 'src/award/award.schema';
import { BlogSchema } from 'src/blog/blog.schema.';
import { BandSchema } from 'src/band/band.schema';
import { bandDateSchema } from 'src/band/bandDates/band-date.schema';
import { SectionSchema } from 'src/section/section.schema';
import { CommentSchema } from 'src/comment/comment.schema';
import { GallerySchema } from 'src/gallery/gallery.schema';
import { ComparesSchema } from 'src/compares/compares.schema';
@Module({
  imports: [MongooseModule.forFeature([
    { name: 'Festival', schema: FestivalSchema },
    { name: "City", schema: citySchema },
    { name: "FestivalYear", schema: FYearSchema },
    { name: "Dates", schema: DatesSchema },
    { name: "Event", schema: EventSchema },
    { name: "Award", schema: AwardSchema },
    { name: "Blog", schema: BlogSchema },
    { name: "Band", schema: BandSchema },
    { name: "BandDate", schema: bandDateSchema },
    { name: "Section", schema: SectionSchema },
    { name: "Comment", schema: CommentSchema },
    { name: "Gallery", schema: GallerySchema },
    { name: "Compares", schema: ComparesSchema },
  ])],
  exports: [MongooseModule.forFeature([{ name: "Festival", schema: FestivalSchema }])],
  providers: [FestivalService],
  controllers: [FestivalController],
})
export class FestivalModule { }
