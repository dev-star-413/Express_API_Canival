import { Injectable } from "@nestjs/common";
import { constants} from 'fs';
import { access, writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import getConfig from 'src/config/config.service';

const config = getConfig()

@Injectable()
export class FunctionsService {
  constructor() {

  }
  randomToken(len) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < len; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }
  async saveFiles(files, dest) {
    try {
      if (!Array.isArray(files)) {
        files = [files];
      }
      const output = [];
      for (const file of files) {
        const mime = file.type;
        if (mime.includes("image")) {
            const prefix = config[dest] || config["defaultImages"];
            const filename = file.name;
            const ext = filename.split(".").pop();
            const newfilename = this.randomToken(16)+"."+ext
            const pathToWrite = join(config.adminProjectPath, 'public', prefix);
            if (!await this.promiseExists(pathToWrite)){
              await mkdir(pathToWrite, {recursive: true});
            }
            const { originalFileName, finalFileName } = await this.writeTheFirstPossible(
              pathToWrite,
              newfilename,
              Buffer.from(file.base64, 'base64')
            );
            output.push({ name: newfilename, path: finalFileName, mime });
        }
      }
  
      return output;
    } catch (error) {
      console.error(error)
    }
  }
  
  async writeTheFirstPossible(path, fileName, data) {
    try {
      const originalFileName = fileName;
      let noDuplicateFileName = originalFileName;
      let noDuplicateNumber = 1;
      let writePath = join(path, noDuplicateFileName);
      while (await this.promiseExists(writePath)) {
        const beforeExtension = originalFileName.substring(0, originalFileName.lastIndexOf("."));
        const extension = originalFileName.split(".").pop();
        noDuplicateFileName = beforeExtension + "-" + noDuplicateNumber + "." + extension;
        noDuplicateNumber++;
        writePath = join(path, noDuplicateFileName);
      }
  
      console.log(writePath)
      await writeFile(writePath, data);
      return { originalFileName, finalFileName: noDuplicateFileName };
    } catch (err) {
      throw err;
    }
  }
  
  async promiseExists(path) {
    try {
      await access(path, constants.R_OK);
      return true;
    } catch (err) {
      if (err.code === "ENOENT") {
        return false;
      } else {
        throw err;
      }
    }
  }

}