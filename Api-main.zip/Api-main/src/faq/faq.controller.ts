import { Controller, Get, Post, Body, Put, Param, Delete } from '@nestjs/common';
import { FaqService } from './faq.service';

@Controller('faq')
export class FaqController {
  constructor(private faqService: FaqService) { }

  @Get()
  async findAll(): Promise<any> {
    try {
      return await this.faqService.findAll();
    } catch (error) {
      return { code: -1, msg: error }
    }
  }
}
