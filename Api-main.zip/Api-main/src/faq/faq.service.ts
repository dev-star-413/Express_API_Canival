import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FAQDocument } from './faq.schema';

@Injectable()
export class FaqService {
  constructor(@InjectModel('FAQ') private faqModel: Model<FAQDocument>) { }

  async findAll(): Promise<any> {
    try {
      const categories = await this.faqModel.find().distinct('cat');
      const faqs = await this.faqModel.find({}, "q a cat createAt");
      categories.sort();
      const result = [];
      categories.map(category => {
        result.push({
          category: category,
          faqs: faqs.filter(faq => faq.cat === category)
        });
      });

      return result;
    } catch (error) {
      console.error(error);
    }
  }
}