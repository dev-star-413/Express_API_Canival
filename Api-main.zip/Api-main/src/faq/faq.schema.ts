import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

@Schema()
export class FAQ {
    @Prop()
    q: string;
    @Prop()
    a: string;
    @Prop()
    cat: string;
    @Prop({ default: Date.now })
    createAt: Date;
    @Prop()
    deleteAt: Date;
}

export type FAQDocument = FAQ & Document;
export const FAQSchema = SchemaFactory.createForClass(FAQ);