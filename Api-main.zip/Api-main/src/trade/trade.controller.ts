import { Controller, Get, Post, Body, Put, Param, Delete } from '@nestjs/common';
import { TradeService } from './trade.service';

@Controller('trade')
export class TradeController {
  constructor(private tradeService: TradeService) { }

  @Post()
  async create(@Body() body) {
    try {
      return await this.tradeService.create(body);
    } catch (error) {
      return { code: -1, msg: error }
    }
  }

  @Get()
  async findAll() {
    try {
      return await this.tradeService.findAll();
    } catch (error) {
      return { code: -1, msg: error }
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      return await this.tradeService.findOne(+id);
    } catch (error) {
      return { code: -1, msg: error }
    }
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() bdoy) {
    return await this.tradeService.update(+id);
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    return await this.tradeService.remove(+id);
  }
}