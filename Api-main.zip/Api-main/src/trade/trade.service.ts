import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { TradeDocument } from "./trade.schema";
import { Model } from "mongoose";

@Injectable()
export class TradeService {
  constructor(@InjectModel('Trade') private tradelModel: Model<TradeDocument>) { }
  async create(params): Promise<any> {
    try {
      const data = {
        title: params.title,
        festivals: params.festivals,
        type: params.type,
        tickets: params.tickets,
        price: params.price,
        imgs: params.imgs,
        desc: params.desc,
        eDate: params.eDate,
        contact: params.contact,
        private: params.private,
      }
      const trade = await new this.tradelModel(data);
      return trade.save();
    } catch (error) {
      throw error;
    }
  }

  async findAll() {
    try {
      return await this.tradelModel.find().exec();
    } catch (error) {
      throw error;
    }
  }

  async findOne(id: number) {
    try {
      return await this.tradelModel.findOne({ _id: id }).exec();
    } catch (error) {
      throw error;
    }
  }

  async update(id: number) {
    return `This action updates a #${id} trade`;
  }

  async remove(id: number) {
    return `This action removes a #${id} trade`;
  }
}
