import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

@Schema()
export class Trade {
    @Prop({ required: true })
    title: string;
    @Prop({ required: true, type: Object })
    festivals: Object;
    @Prop()
    type: String;
    @Prop({ required: true, type: Object })
    tickets: Object;
    @Prop()
    price: Number;
    @Prop({ type: Object })
    imgs: Object;
    @Prop()
    desc: string;
    @Prop()
    eDate: Date;
    @Prop({ type: Object })
    contact: Object;
    @Prop({ default: false })
    private: Boolean;
}

export type TradeDocument = Trade & Document;
export const TradeSchema = SchemaFactory.createForClass(Trade);