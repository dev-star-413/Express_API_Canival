import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { DateDocument } from 'src/dates/dates.schema';
import { WatchListDocument } from './watch-list.schema';

@Injectable()
export class WatchListService {
    constructor(
        @InjectModel("WatchList") private watchlistModel: Model<WatchListDocument>,
        @InjectModel("date") private DateModel: Model<DateDocument>
    ) { }

    async get(userId) {
        if (!userId) return { code: -1, msg: "failed" }
        var watchList: any = await this.watchlistModel.find({ userId: userId }).sort('created ASC')
        // find all data from collection 
        var list: any = []
        for (var item of watchList) {
            item = item.toObject()
            var id = item.caseId
            switch (item.collName) {
                case "dates":
                    var fdate: any = await this.DateModel.find({
                        _id: id,
                        // $or: [
                        //     {
                        //         bestE: { $gte: new Date() }
                        //     },
                        //     {
                        //         paradeE: { $gte: new Date() }
                        //     }
                        // ]
                    })
                    if (fdate && fdate[0]) {
                        fdate = fdate && fdate[0]
                        var { bestE, bestS, paradeE, paradeS, price, year, festival, img, desc, slug } = fdate
                        list.push({ ...item, bestE, bestS, paradeE, paradeS, price, year, festival, img, desc, slug })
                    }
                    else {
                        // remove event from watch list
                        await this.watchlistModel.deleteOne({ _id: item._id })
                    }
                    break
            }
        }
        return { code: 0, msg: "success", data: list }
    }
    async create(body, userId) {
        try {
            const { caseId, collName } = body
            if (!userId || !caseId || !collName) return { code: -1, msg: "Some parameters have been missed." }
            const data = {
                userId, collName, caseId
            }
            const wtl = await new this.watchlistModel(data)
            wtl.save()
            return { code: 1, msg: "success", data: wtl }
        } catch (error) {
            return { code: -1, msg: "Error occurred while creating the new watch list object." }
        }
    }
    async remove(params) {
        try {
            const { id } = params
            if (!id) return { code: 0, msg: "Watch list Id has been missed." }
            await this.watchlistModel.deleteOne({ _id: id })
            return { code: 1, msg: "success" }
        } catch (error) {
            return { code: -1, msg: "Error occurred while removing watch list." }
        }
    }
    async check(query, userId) {
        try {
            const { caseId, collName } = query
            if (!caseId || !userId || !collName) return { code: -1, msg: "Please send caseId, collName and userId." }
            const exist = await this.watchlistModel.findOne({ caseId, userId, collName })
            return { code: 1, msg: "success", data: exist }
        } catch (error) {
            return { code: -1, msg: "Error occurred while checking watch list." }
        }
    }
}
