import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose'

export type WatchListDocument = WatchList & Document
@Schema()
export class WatchList {
    @Prop({ required: true })
    userId: String;
    @Prop({ required: true, trim: true })
    collName: String;
    @Prop({ required: true })
    caseId: String;
    @Prop({ required: true, default: new Date() })
    createAt: Date;
    @Prop()
    deleteAt: Date;
}


export const WatchListSchema = SchemaFactory.createForClass(WatchList);