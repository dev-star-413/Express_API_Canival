import { Body, Controller, Get, Param, Post, Query, Res } from '@nestjs/common';
import { Response } from 'express';
import { WatchListService } from './watch-list.service';

@Controller('watch-list')
export class WatchListController {
    constructor(private watchListService: WatchListService) { }
    @Get()
    async get(@Res() res: Response): Promise<any> {
        res.json(await this.watchListService.get(res.locals.userId))
    }
    @Post()
    async add(@Body() Body, @Res() res: Response): Promise<any> {
        res.json(await this.watchListService.create(Body, res.locals.userId))
    }
    @Post('/remove/:id')
    async remove(@Param() params): Promise<any> {
        return await this.watchListService.remove(params)
    }
    @Get('/check')
    async check(@Query() query, @Res() res: Response): Promise<any> {
        res.json(await this.watchListService.check(query, res.locals.userId))
    }
}
