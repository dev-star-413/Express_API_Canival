import { Module } from '@nestjs/common';
import { WatchListService } from './watch-list.service';
import { WatchListController } from './watch-list.controller';
import { WatchListSchema } from './watch-list.schema';
import { MongooseModule } from '@nestjs/mongoose';
import { DatesSchema } from 'src/dates/dates.schema';

@Module({
  imports: [MongooseModule.forFeature([
    { name: 'WatchList', schema: WatchListSchema },
    { name: 'date', schema: DatesSchema }
  ])],
  exports: [MongooseModule.forFeature([{ name: 'WatchList', schema: WatchListSchema }])],
  providers: [WatchListService],
  controllers: [WatchListController]
})
export class WatchListModule { }
