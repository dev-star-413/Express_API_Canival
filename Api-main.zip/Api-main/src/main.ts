import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import getConfig from './config/config.service';
import * as bodyParser from 'body-parser'
async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(bodyParser.json({limit: '256mb'}));
  app.use(bodyParser.urlencoded({limit: '256mb', extended: true}));

  app.setGlobalPrefix('api/v1')
  app.enableCors({ 
    origin:["http://festivals.parkcityhosting.com", "https://festivals.parkcityhosting.com", "http://localhost:3000", 'https://localhost:3000',
      "https://hellocarnival.com", "https://dev.hellocarnival.com", "http://localhost:3002", "https://www.hellocarnival.com", "https://www.dev.hellocarnival.com"],
    methods: ["GET", "HEAD", "PUT", "PATCH", "POST", "DELETE"]
  })
  const config = new DocumentBuilder()
    .setTitle('Festival API')
    .setDescription('Documention API')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document);
  if(process.env.NODE_ENV === "production" || process.env.NODE_ENV === "development") {
    await app.listen(getConfig().port, "127.0.0.1");
  } else {
    await app.listen(getConfig().port);
  }
  console.log(`=================== STARTED on port ${getConfig().port} ===================`);
}
bootstrap();
