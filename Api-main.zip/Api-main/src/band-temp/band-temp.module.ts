import { Module } from '@nestjs/common';
import { BandTempService } from './band-temp.service';
import { BandTempController } from './band-temp.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { bandTempSchema } from './band-temp.schema';
import { SectionSchema } from 'src/section/section.schema';
import { LineSchema } from 'src/line/line.schema';
import { BandSchema } from 'src/band/band.schema';
import { DatesSchema } from 'src/dates/dates.schema';
import { DesignerSchema } from 'src/designer/designer.schema';

@Module({
  controllers: [BandTempController],
  providers: [BandTempService],
  imports: [MongooseModule.forFeature([
    { name: 'BandTemp', schema: bandTempSchema },
    { name: 'Section', schema: SectionSchema },
    { name: 'Line', schema: LineSchema },
    { name: 'Band', schema: BandSchema },
    { name: 'Date', schema: DatesSchema },
    { name: 'Designer', schema: DesignerSchema },
  ])]
})
export class BandTempModule { }
