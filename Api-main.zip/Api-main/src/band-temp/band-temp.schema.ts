import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

@Schema()
export class BandTemp {
    // band date
    @Prop({ type: String, required: true })
    bandId: string
    @Prop({ type: String, required: true })
    name: string
    @Prop({ type: String })
    dateId: string
    @Prop({ type: String })
    dateName: string
    @Prop({ type: Number })
    year: number
    @Prop({ type: String })
    themeType: string
    @Prop({ type: String, trim: true })
    theme: string
    @Prop({ type: Date })
    lDate: Date
    @Prop({ type: Date })
    rdDate: Date
    @Prop({ type: Object })
    video: {
        name: string,
        path: string,
        mime: string
    }
    @Prop({ type: [Object] })
    imgs: Array<{
        name: string,
        path: string,
        mime: string
    }>
    @Prop()
    deposit: number
    @Prop({ type: String, trim: true })
    desc: string
    @Prop({ type: String })
    reveller: string
    @Prop({ type: Number })
    locals: number
    @Prop({ type: String })
    slug: string
    @Prop({ type: Number })
    likeC: number // like count
    @Prop({ type: Number })
    commentC: number // comment count
    @Prop({ type: Number })
    @Prop({ type: Object })
    comments: object // last 10 comments
    @Prop({ type: Number })
    hot: number
    @Prop({ type: [Object] })
    scores: Array<{
        title: string;
        desc: string;
        score: number;
    }>
    @Prop({ type: [String], default: [] })
    agree: Array<string>
    @Prop({ type: [String], default: [] })
    disagree: Array<string>
    @Prop({ type: [String], default: [] })
    notsure: Array<string>
    @Prop()
    sectionOptions: string;
    @Prop({ default: 0 })
    score: number;
    @Prop({ type: Object })
    reviews: object
    @Prop({ type: Array, default: [] })
    services: []
    @Prop({ type: Number, default: 0 })
    sections: number
    @Prop({ type: Date, default: new Date() })
    createAt: Date
    @Prop()
    deleteAt: Date;
    @Prop()
    by: string;
    @Prop({ default: new Date() })
    at: Date;
    @Prop({ default: false })
    confirmed: boolean;
    @Prop()
    confirmedDate: Date;
    @Prop()
    confirmedBy: string;
}
export type BandTempDocument = BandTemp & Document
export const bandTempSchema = SchemaFactory.createForClass(BandTemp)