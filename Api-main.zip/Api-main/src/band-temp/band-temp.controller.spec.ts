import { Test, TestingModule } from '@nestjs/testing';
import { BandTempController } from './band-temp.controller';
import { BandTempService } from './band-temp.service';

describe('BandTempController', () => {
  let controller: BandTempController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [BandTempController],
      providers: [BandTempService],
    }).compile();

    controller = module.get<BandTempController>(BandTempController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
