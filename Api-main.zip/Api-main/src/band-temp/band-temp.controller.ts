import { Body, Controller, Post, Res } from '@nestjs/common';
import { Response } from 'express';
import { BandTempService } from './band-temp.service';

@Controller('band-temp')
export class BandTempController {
  constructor(private readonly bandTempService: BandTempService) { }
  @Post('/create')
  async createBandTemp(@Body() body, @Res() res: Response): Promise<any> {
    res.json(await this.bandTempService.create(body, res.locals.userId))
  }
}
