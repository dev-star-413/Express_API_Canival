import { Test, TestingModule } from '@nestjs/testing';
import { BandTempService } from './band-temp.service';

describe('BandTempService', () => {
  let service: BandTempService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [BandTempService],
    }).compile();

    service = module.get<BandTempService>(BandTempService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
