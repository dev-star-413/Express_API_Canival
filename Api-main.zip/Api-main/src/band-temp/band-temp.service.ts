import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { BandDocument } from 'src/band/band.schema';
import { DateDocument } from 'src/dates/dates.schema';
import { DesignerDocument } from 'src/designer/designer.schema';
import { LineDocument } from 'src/line/line.schema';
import { SectionDocument } from 'src/section/section.schema';
import { BandTempDocument } from './band-temp.schema';

@Injectable()
export class BandTempService {
    constructor(
        @InjectModel('BandTemp') private bandTempModel: Model<BandTempDocument>,
        @InjectModel('Section') private sectionModel: Model<SectionDocument>,
        @InjectModel('Line') private lineModel: Model<LineDocument>,
        @InjectModel('Band') private bandModel: Model<BandDocument>,
        @InjectModel('Date') private dateModel: Model<DateDocument>,
        @InjectModel('Designer') private designerModel: Model<DesignerDocument>,
    ) { }
    async create(body, userId): Promise<any> {
        try {
            let { band, sections } = body;
            let bandData = await this.bandModel.findById(band.bandId, "_id name");
            let dateData = await this.dateModel.findById(band.dateId, "_id festival");
            band = { ...band, by: userId, name: bandData.name, dateName: dateData.festival.name }
            // create band temp
            const newBand = await this.bandTempModel.create(band);
            // create section and line temps
            sections.map(async section => {
                if (section.name && section.types) {
                    const desingers = []
                    section.designers.map(async designer => {
                        const designerData = await this.designerModel.findById(designer, "_id name");
                        desingers.push({
                            id: designerData._id.toString(),
                            name: designerData.name
                        });
                    });
                    const soldByData = await this.bandModel.findById(section.soldBy, "_id name");
                    const bandData = {
                        id: soldByData._id.toString(),
                        name: soldByData.name
                    }
                    section = { ...section, soldBy: bandData, desingers: desingers, bdId: newBand._id.toString(), by: userId }
                    const newSection = await this.sectionModel.create(section);
                    section.lines.map(async line => {
                        if (line.type) {
                            line = { ...line, sId: newSection._id.toString() }
                            await this.lineModel.create(line)
                        }
                    });
                }
            })
            return { code: 1, msg: 'Your request submitted successfully!' }
        } catch (error) {
            return { code: -1, msg: 'Error occurred while creating your band date.' }
        }
    }
}