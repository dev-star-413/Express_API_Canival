import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { QuoteService } from './quote.service';

@Controller('quote')
export class QuoteController {
  constructor(private readonly quoteService: QuoteService) { }
  @Post("/create")
  async create(@Body() body): Promise<any> {
    return await this.quoteService.create(body);
  }

  @Post("/update")
  async update(@Body() body): Promise<any> {
    return await this.quoteService.update(body);
  }

  @Delete("/:id")
  async deleteById(@Param() params): Promise<any> {
    return await this.quoteService.delete(params);
  }

  @Get()
  async getActiveQuotes(): Promise<any> {
    return await this.quoteService.getActiveQuotes();
  }
}
