import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

@Schema()
export class Quote {
    @Prop({ required: true })
    quote: string;
    @Prop({ required: true })
    source: string;
    @Prop({required: true})
    active: Boolean;
    @Prop({ required: true, default: Date.now })
    createAt: Date;
}

export type QuoteDocument = Quote & Document;
export const QuoteSchema = SchemaFactory.createForClass(Quote);