import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { QuoteDocument } from './quote.schema';

@Injectable()
export class QuoteService {
    constructor(@InjectModel("Quote") private quoteModel: Model<QuoteDocument>) { }
    async create(body): Promise<any> {
        try {
            let data = {
                quote: body.quote,
                source: body.source,
                active: body.active,
            }
            return await new this.quoteModel(data).save();
        } catch (error) {
            return { code: -1, msg: error };
        }
    }

    async update(body): Promise<any> {
        try {
            return await this.quoteModel.updateOne({ _id: body.id }, { quote: body.quote, source: body.source, active: body.active });
        } catch (error) {
            return { code: -1, msg: error };
        }
    }

    async delete(params): Promise<any> {
        try {
            return await this.quoteModel.deleteOne({ _id: params.id });
        } catch (error) {
            return { code: -1, msg: error };
        }
    }

    async getActiveQuotes(): Promise<any> {
        try {
            const quotes = await this.quoteModel.find({ active: true });
            const returners = [];
            // return three random active quotes
            for (let index = 0; index < 3; index++) {
                const randomNumber = Math.floor(Math.random() * (quotes.length - 1));
                returners.push(quotes.splice(randomNumber, 1)[0]);
            }
            return returners;
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
}
