import { Body, Controller, Get, Param, Post, Query, Res } from '@nestjs/common';
import { BandService } from './band.service';
import { CreateBand } from './dto/create';

@Controller('band')
export class BandController {
  constructor(private bandService: BandService) { }
  @Post()
  async create(@Body() body: CreateBand): Promise<any> {
    return await this.bandService.create(body)
  }
  @Get("/landing/:number")
  async getSome(@Param() params): Promise<any> {
    return await this.bandService.getSome(params);
  }

  @Get("/form/params")
  async getFormParams(): Promise<any> {
    return await this.bandService.getFormParams();
  }

  @Get("/filter/params")
  async getFilterParams(): Promise<any> {
    return await this.bandService.getFilterParams();
  }

  @Get("/:slug")
  async get(@Param() param): Promise<any> {
    return await this.bandService.get(param);
  }
  @Get("/like/:slug")
  async like(@Param() params) {
    return await this.bandService.like(params);
  }
  @Get("/search/name")
  async searchBand(@Query() param):Promise<any>{
    return await this.bandService.search(param)
  }
}
