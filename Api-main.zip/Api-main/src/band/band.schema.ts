import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

@Schema()
export class Band {
    @Prop({ required: true })
    name: string;
    @Prop({ required: true })
    about: string;
    @Prop()
    foundY: string;
    @Prop()
    unique: string;
    @Prop()
    uID: string;
    @Prop()
    likeC: number;
    @Prop()
    slug: string;
    @Prop()
    lastYear:string;
    @Prop({type:Object})
    img:Object;
    @Prop({ required: true, default: Date.now })
    createAt: Date;
    @Prop()
    deleteAt: Date;
    @Prop()
    contactPhone: String;
    @Prop()
    contactEmail: String;
}

export type BandDocument = Band & Document;
export const BandSchema = SchemaFactory.createForClass(Band);