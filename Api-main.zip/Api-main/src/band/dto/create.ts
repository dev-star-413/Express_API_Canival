import { ApiProperty } from "@nestjs/swagger";

export class CreateBand{
    @ApiProperty({
        description:'name band',
    })
    name:string
    
    @ApiProperty({
        description:'description about band',
    })
    desc:string
    @ApiProperty({
        description:'theme band',
    })
    theme:string
    @ApiProperty({
        description:'type band',
    })
    type:string
    @ApiProperty({
        description:'launch date band',
    })
    launch:Date
    @ApiProperty({
        description:'list carnivals id',
    })
    carival:object
    @ApiProperty({
        description:'list sections id',
    })
    sections:object

    @ApiProperty({
        description:'slug band',
    })
    slug:string
}