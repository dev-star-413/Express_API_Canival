import { Module } from '@nestjs/common';
import { BandService } from './band.service';
import { BandController } from './band.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { BandSchema } from "./band.schema";
import { DatesSchema } from 'src/dates/dates.schema';
import { DesignerSchema } from 'src/designer/designer.schema';
import { DynamicSchema } from 'src/dynamic/dynamic.schema';
import { bandDateSchema } from './bandDates/band-date.schema';
import { AwardSchema } from 'src/award/award.schema';
import { BlogSchema } from 'src/blog/blog.schema.';
import { GallerySchema } from 'src/gallery/gallery.schema';

@Module({
  controllers: [BandController],
  providers: [BandService],
  imports: [MongooseModule.forFeature([
    { name: "Band", schema: BandSchema },
    { name: "Date", schema: DatesSchema },
    { name: "Designer", schema: DesignerSchema },
    { name: "Dynamic", schema: DynamicSchema },
    { name: "BandDate", schema: bandDateSchema },
    { name: "Award", schema: AwardSchema },
    { name: "Blog", schema: BlogSchema},
    { name: "Gallery", schema: GallerySchema},


  ])],
})
export class BandModule { }
