import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

@Schema()
export class BandDate {
    // band date
    @Prop({ type: String, required: true })
    bandId: string
    @Prop({ type: String, required: true })
    name: string
    @Prop({ type: String })
    dateId: string
    @Prop({ type: String })
    dateName: string
    @Prop({ type: Number })
    year: number
    @Prop({ type: String })
    themeType: string
    @Prop({ type: String, trim: true })
    theme: string
    @Prop({ type: Date })
    lDate: Date
    @Prop({ type: Date })
    rdDate: Date
    @Prop({ type: Object })
    video: {
        name: string,
        path: string,
        mime: string
    }
    @Prop({ type: [Object] })
    imgs: Array<{
        name: string,
        path: string,
        mime: string
    }>
    @Prop({type: [Object], default: []})
    compares: Array<{
        sections: Array<{
            _id: string;
            name: string;
            img: string;
        }>
    }>
    @Prop()
    deposit: number
    @Prop({ type: String, trim: true })
    desc: string
    @Prop({ type: String })
    reveller: string
    @Prop({ type: Number })
    locals: number
    @Prop({ type: String })
    slug: string
    @Prop({ type: Number })
    likeC: number // like count
    @Prop({ type: Number })
    commentC: number // comment count
    @Prop({ type: Object })
    comments: object // last 10 comments
    @Prop({ type: Number })
    hot: number
    @Prop({ type: [Object] })
    scores: Array<{
        title: string;
        desc: string;
        score: number;
    }>
    @Prop({ default: 0 })
    agree: Number;
    @Prop({ default: 0 })
    disagree: Number;
    @Prop({ default: 0 })
    notsure: Number;
    @Prop()
    sectionOptions: string;
    @Prop({ default: 0 })
    score: number;
    @Prop({ type: Object })
    reviews: object
    @Prop({ type: Array, default: [] }) 
    services: [] // costume services 
    @Prop({ type: Array, default: [] }) 
    jouvertServices:[]
    @Prop({type:Boolean,default:false})
    isCustomeService:boolean
    @Prop({type:Boolean,default:false})
    isJouvertService:boolean
    @Prop({ type: Number, default: 0 })
    sections: number
    @Prop({ default: 0 })
    avgScore: number;
    @Prop({ default: 0 })
    sumOfReviews: number;
    @Prop({ type: Date, default: new Date() })
    createAt: Date
    @Prop()
    deleteAt: Date;
    @Prop()
    reviewText: string;
    @Prop()
    meta: string;
    @Prop({type: Object})
    jImg: {
        name: string,
        path: string,
        mime: string
    };
    @Prop({type: Object})
    jlImg: {
        name: string,
        path: string,
        mime: string
    };
    @Prop({type:String})
    link:string;
    @Prop({type:String})
    rdCurrency:string
    @Prop({type:Boolean,default:false})
    confirm:boolean;
    @Prop({type:Boolean,default:false})
    complete:boolean;
    // ___________________________________________________
    @Prop({type: Object})
    mainImg:object ;
    @Prop({type:Boolean,default:false})
    isChildrenService:boolean;
    @Prop({type:Array,default:[]})
    childrenServices:[];
    @Prop({type: Object})
    costumeImg:object;
    @Prop({type:Object})
    costumeLImg:object;
    @Prop({type:String})
    jouvertTheme:string;
    @Prop({})
    jouvertLaunchDate:Date;
    @Prop()
    jouvertDeadlineDate:Date
    @Prop({type:Object})
    childrenImg:object;
    @Prop({type:Object})
    childrenlImg:object;
    @Prop({type:String})
    childrenTheme:string;
    @Prop()
    childrenLaunchDate:Date;
    @Prop()
    childrenDeadlineDate:Date;
    @Prop({type:String})
    details:string;
    @Prop({type:String})
    preRegisPrice:string;
    @Prop()
    preRegisDeadLine:Date;

    @Prop({type:Boolean,default:false})
    showAdult:boolean
    @Prop({type:Boolean,default:false})
    showJouvert:boolean 
    @Prop({type:Boolean,default:false})
    showChildren:boolean
}
export type BandDateDocument = BandDate & Document
export const bandDateSchema = SchemaFactory.createForClass(BandDate)
