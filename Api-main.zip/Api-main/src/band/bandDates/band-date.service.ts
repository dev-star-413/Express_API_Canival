import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import * as moment from "moment";
import * as md5 from "md5";
import { Model } from 'mongoose';
import { BlogDocument } from "src/blog/blog.schema.";
import { CityDocument } from "src/city/city.schema";
import { DateDocument } from "src/dates/dates.schema";
import { EventDocument } from "src/event/event.schema";
import { LineDocument } from "src/line/line.schema";
import { SectionDocument } from "src/section/section.schema";
import { BandDocument } from "../band.schema";
import { BandDateDocument } from "./band-date.schema";
import getConfig from "src/config/config.service";
import { AwardDocument } from "src/award/award.schema";
import { DynamicDocument } from "src/dynamic/dynamic.schema";
import { UserDocument } from "src/user/user.schema";
import { CommentDocument } from "src/comment/comment.schema";
import { VoteDocument } from "src/vote/vote.schema";
import { salt } from "src/award/award.service";
import { Request } from "express";
import { CurrencyRateDocument } from "src/currencyRate/currencyRate.schema";
import { GalleryDocument } from "src/gallery/gallery.schema";
const config = getConfig();
const profilesPrefix='profiles'

@Injectable()
export class BandDateService {
    constructor(
        @InjectModel("BandDate") private bandDateModel: Model<BandDateDocument>,
        @InjectModel("Section") private sectionModel: Model<SectionDocument>,
        @InjectModel("Line") private lineModel: Model<LineDocument>,
        @InjectModel("Dates") private dateModel: Model<DateDocument>,
        @InjectModel("City") private cityModel: Model<CityDocument>,
        @InjectModel("Band") private bandModel: Model<BandDocument>,
        @InjectModel("Blog") private blogModel: Model<BlogDocument>,
        @InjectModel("Event") private eventModal: Model<EventDocument>,
        @InjectModel('Award') private awardModel: Model<AwardDocument>,
        @InjectModel("Dynamic") private dynamicModel: Model<DynamicDocument>,
        @InjectModel("User") private userModel: Model<UserDocument>,
        @InjectModel("Comment") private commentModel: Model<CommentDocument>,
        @InjectModel("Vote") private voteModel: Model<VoteDocument>,
        @InjectModel("CurrencyRate") private currencyRate: Model<CurrencyRateDocument>,
        @InjectModel("Gallery") private galleryModel: Model<GalleryDocument>,

    ) { }
    async getAll(query) {
        try {
            let { year, carnival, band, sections } = query;
            sections = sections ? sections.split(',') : false;
            try {
                year = parseInt(year);
            } catch (error) {
                year = parseInt(moment(new Date()).format("YYYY"));
            }
            var bandDates = [];
            if(year !== 0) {
              bandDates = await this.bandDateModel.find({ year: year }, "slug name year mainImg dateId deposit bandId");
            } else {
              bandDates = await this.bandDateModel.find({}, "slug name year mainImg dateId deposit bandId");
            }

            if (carnival) {
                bandDates = bandDates.filter(bd => bd.dateId == carnival);
            }
            if (band) {
                bandDates = bandDates.filter(bd => bd.bandId == band);
            }
            const result = [];
            for (let bandDate of bandDates) {
                let dates = await this.dateModel.findById(bandDate.dateId, "_id festival city");
                if (bandDate.mainImg) {
                    bandDate.mainImg = `${config.imgDomain}${config.bandImages}/${bandDate.mainImg.path}`
                }
                let city;
                if (dates.city) {
                    city = await this.cityModel.findById(dates.city, "name code")
                }
                const sectionsTemp = sections ?
                    await this.sectionModel.find({ bdId: bandDate._id, types: { $in: sections } }, "name average img deposit")
                    :
                    await this.sectionModel.find({ bdId: bandDate._id }, "name average img deposit");
                if (sections && sectionsTemp.length === 0) {
                    continue
                }
                let hotness = 0;
                let sum = 0;
                sectionsTemp.map(section => {
                    sum += section.average;
                    if (section.img) {
                        section.img.path = `${config.imgDomain}${config.sectionImages}/${section.img.path}`
                    }
                    hotness = sum / sectionsTemp.length;
                    result.push({
                        slug: bandDate.slug,
                        name: section.name,
                        bandName: bandDate.name,
                        dateName: dates.festival && dates.festival.name,
                        year: bandDate.year,
                        img: section.img,
                        city: city,
                        deposit: bandDate.deposit || 0,
                        hotness: section.average || 0,
                    })
                });
            }
            return result;
        } catch (error) {
            console.error(error)
            return { code: -1, msg: "Error occurred while getting band dates." }
        }
    }

    async getBySlug(userID: string, params) {
        try {
            const { slug } = params;
            // gather band date data
            var bandDate = await this.bandDateModel.findOne({ slug: slug }).lean();
            var lines = [];
            var band;
            var events = [];
            var reviews = [];
            var guides = [];
            var carnivals;
            var bands;
            var bandSections;
            var years;
            var carnival;
            var awards = [];
            var sections = [];
            var comments = [];
            var dynamics = {}
            var news=[]
            if(!bandDate) {
              return { code: -2, msg: "No band date found with slug: " + params.slug }
            }
            if(bandDate.jouvertLaunchDate) bandDate.jouvertLaunchDate=moment( bandDate.jouvertLaunchDate).utc().format('ddd, MMM D YYYY');
            if(bandDate.jouvertDeadlineDate) bandDate.jouvertDeadlineDate=moment( bandDate.jouvertDeadlineDate).utc().format('ddd, MMM D YYYY');
            if(bandDate.childrenLaunchDate) bandDate.childrenLaunchDate=moment( bandDate.childrenLaunchDate).utc().format('ddd, MMM D YYYY');
            if(bandDate.childrenDeadlineDate) bandDate.childrenDeadlineDate=moment( bandDate.childrenDeadlineDate).utc().format('ddd, MMM D YYYY');
            if(bandDate.preRegisDeadLine) bandDate.preRegisDeadLine=moment( bandDate.preRegisDeadLine).utc().format('ddd, MMM D YYYY');


            var CurrencyRates=await this.currencyRate.find({})
            carnival = await this.dateModel.findById(
                bandDate.dateId,
                '_id  guide year bestE slug jouvert festival paradeS paradeE jouvertStartDate jouvertEndDate childrenStartD childrenEndD jouvertAddress childrenParadeAddress paradeLocation'
            ).lean();
            if(carnival.paradeS)
                carnival.paradeS=moment( carnival.paradeS).utc().format('MMM Do YYYY, hh:mm A');
            if(carnival.paradeE)
                carnival.paradeE=moment( carnival.paradeE).utc().format('MMM Do YYYY, hh:mm A');
            if(carnival.jouvertStartDate)
                carnival.jouvertStartDate=moment( carnival.jouvertStartDate).utc().format('MMM Do YYYY, hh:mm A');
            if(carnival.jouvertEndDate)
                carnival.jouvertEndDate=moment( carnival.jouvertEndDate).utc().format('MMM Do YYYY, hh:mm A');
            if(carnival.childrenStartD)
                carnival.childrenStartD=moment( carnival.childrenStartD).utc().format('MMM Do YYYY, hh:mm A');
            if(carnival.childrenEndD)
                carnival.childrenEndD=moment( carnival.childrenEndD).utc().format('MMM Do YYYY, hh:mm A');
            var fID=carnival  && carnival.festival && carnival.festival.id
            events = await this.eventModal.find({ 'tags.id':bandDate.bandId, canceled: false }, "name slug vName sDate");
            band = await this.bandModel.findById(bandDate.bandId, "name foundY about img slug").sort({name:1});
            reviews = await this.blogModel.find({ "bands._id": band._id, cats: ['Reviews'] }, "title img author pDate slug meta")
            news = await this.blogModel.find({ "bands._id": band._id, cats: ['News'] }, "title img author pDate slug meta")
            guides = await this.blogModel.find({ "bands._id": band._id,"festivals._id":fID, cats: ['Guides'] }, "title img author pDate slug meta");
            if(bandDate.mainImg){
                bandDate.mainImg.path=encoder(`${config.imgDomain}${config.bandImages}/${bandDate.mainImg.path}`);
            }
            else if(band.img){
                band.img.path=encoder(`${config.imgDomain}${config.bandImages}/${band.img.path}`);
                bandDate.mainImg=band.img
            }
            
            // console.log(guides)
            var comparisons = bandDate.compares;
            // make  carnival image path
            if(bandDate.jImg){
                bandDate.jImg.path=encoder(`${config.imgDomain}${config.bandImages}/${bandDate.jImg.path}`);
            }
            if(bandDate.jlImg){
                bandDate.jlImg.path=encoder(`${config.imgDomain}${config.bandImages}/${bandDate.jlImg.path}`);
            }
            // make band date images path
            if (bandDate.imgs) {
                for (let img of bandDate.imgs) {
                    img.path = encoder(`${config.imgDomain}${config.bandImages}/${img.path}`);
                }
            }
            // make band date video path
            if (bandDate.video) {
                bandDate.video.path = encoder(`${config.domain}${config.videos}/${bandDate.video.path}`);
            }
            // children image
            if(bandDate.childrenImg){
                bandDate.childrenImg.path=encoder(`${config.imgDomain}${config.bandImages}/${bandDate.childrenImg.path}`);
            }
            if(bandDate.childrenlImg){
                bandDate.childrenlImg.path=encoder(`${config.imgDomain}${config.bandImages}/${bandDate.childrenlImg.path}`);
            }
            // costume image
            if(bandDate.costumeImg){
                bandDate.costumeImg.path=encoder(`${config.imgDomain}${config.bandImages}/${bandDate.costumeImg.path}`);
            }
            if(bandDate.costumeLImg){
                bandDate.costumeLImg.path=encoder(`${config.imgDomain}${config.bandImages}/${bandDate.costumeLImg.path}`);
            }
            // make reviews imgs path
            reviews.map((review) => {
                if (review.img) {
                    review.img.path = encoder(`${config.imgDomain}${config.blogImages}/${review.img.path}`);
                }
            })
            // make guides imgs path
            guides.map((guide) => {
                if (guide.img) {
                    guide.img.path = encoder(`${config.imgDomain}${config.blogImages}/${guide.img.path}`);
                }
            })
            // make compare imgs paths
            for (let compare of comparisons) {
                for (let sect of compare.sections) {
                    const section = await this.sectionModel.findById(sect._id, "img name");
                    if (section && section.img) {
                        sect.img = `${config.imgDomain}${config.sectionImages}/${section.img.path}`;
                    }
                }
            }
            // gather reviews and generate image paths
            comments = await this.commentModel.find({ collName: 'band', docID: bandDate._id }).lean();
            for (let comment of comments) {
                if (comment.imgs) {
                    for (let image of comment.imgs) {
                        if (image.path) {
                            image.path = encoder(`${config.imgDomain}${config.commentImages}/${image.path}`);
                        }
                    }
                }
                if(comment.avatar  && !comment.avatar.startsWith("https://")) comment.avatar=`${config.imgDomain}${config[profilesPrefix]}/${comment.avatar}`
                if(comment.likes && Array.isArray(comment.likes)) {
                  if(userID) {
                    comment.likedByMe = Boolean(comment.likes.find(item => item && item.toString() === userID))
                  } 
          
                  comment.likeCount = comment.likes.length
                  delete comment.likes;
                }
            }
            // prepare review form parameters
            carnivals = await this.dateModel.find({ bestE: { $lt: new Date() } }, "_id festival year").sort({'festival.name':1});
            years = await this.dateModel.find({ bestE: { $lt: new Date() } }, "year").distinct('year');
            years=years.sort((a,b)=>b-a)
            //
            bands = await this.bandDateModel.find({ dateId: carnivals.map(carniv => { return carniv._id }) }, "_id name dateId").sort({name:1});
            bandSections = await this.sectionModel.find({ bdId: bands.map(band => { return band._id }) }, "_id name bdId").sort({name:1});
            dynamics = {
                years,
                carnivals,
                bands,
                sections: bandSections,
            };
            // gather awards of this band date
            awards = await this.awardModel.find({ 'cats.positions.bands._id': bandDate._id }, '_id dId cats slug name');
            for (let award of awards) {
                const festivalDate = await this.dateModel.findById(award.dId, '_id festival year');
                award.fDate = festivalDate;
            }
            // gather band date's sections data
            sections = await this.sectionModel.find({ bdId: bandDate._id }).lean();
            if (sections) {
                for (let index in sections) {
                    let section = sections[index];
                    if (section.reviews) {
                        section.reviews = section.reviews.reverse();
                        section.reviews.map(review => {
                            const dif = moment().diff(review.createAt, 'd');
                            if (dif < 1) {
                                review.createAt = moment(review.createAt).utc().format("hh:mm As");
                            } else if (dif == 1) {
                                review.createAt = "yesterday";
                            } else if (dif <= 7) {
                                review.createAt = moment(review.createAt).weekday(review.createAt);
                            } else {
                                review.createAt = moment(review.createAt).utc().format("YYYY-MM-DD hh:mm A");
                            }
                        })
                    }
                    // regenerate section gallery image paths
                    if (section.img) {
                        section.img.path = encoder(`${config.imgDomain}${config.sectionImages}/${section.img.path}`)
                    }
                    // gather lines of the section
                    let linesOfThisSection = await this.lineModel.find({ sId: section._id }).lean()
                    if (linesOfThisSection[0]) {
                        let minPrice = Infinity;
                        let minPriceCurrency="USD"
                        for (let line of linesOfThisSection) {
                            if (line.gallery) {
                                // regenerate line gallery image paths
                                var i=0;
                                for (let image of line.gallery) {
                                    if (image.price && Number(image.price) < minPrice ) {
                                        minPrice = Number(image.price)
                                        minPriceCurrency=image.currency
                                    };
                                    if (image.path) {
                                        image.path = encoder(`${config.imgDomain}${config.lineImages}/${image.path}`)
                                        // image._id=`line-gallery-${i++}`
                                    }
                                }
                            }
                        }
                        section.starts = minPrice;
                        section.currencyStarts=minPriceCurrency
                    }
                    lines = lines.concat(linesOfThisSection);
                    sections[index] = section;
                }
            }
            // get all services
            const services = await this.dynamicModel.findOne({}, "services jouvertServices childrenServices");
            const bandDateDetails = await this.dynamicModel.findOne({}, "bandDateDetails");
            const otherBandsInFY = await this.bandDateModel.find({dateId: bandDate.dateId}, {name: 1, slug: 1,confirm:1,isJouvertService:1,isCustomeService:1,isChildrenService:1,theme:1,sections:1}).sort({name:1});
            const thisBandInOtherFYs = await this.bandDateModel.find({bandId: bandDate.bandId, commentC: {$gt: 0}, _id: {$ne: bandDate._id} }, {name: 1, slug: 1, dateName: 1, year: 1});
            var pastExperience=await this.bandDateModel.find({bandId:bandDate.bandId,year:{$lt: bandDate.year}},'name score dateName theme year slug imgs  mainImg avgScore dateId isJouvertService isCustomeService isChildrenService').sort({rdDate:-1}).lean()
            var galleries:any=await this.galleryModel.find({dateId:bandDate.dateId})

            for(let gallery of galleries){
                gallery=gallery
                var imgs:any=gallery.imgs
                for(let img of imgs){
                    let {mime, path}=img
                    let newPath=(mime.includes('video'))? encoder('localhost:3000'+ config.videos + '/' + path):
                    encoder(config.imgDomain + config.galleryImages + '/' + path)
                    img.path=newPath
                }
            }
            if(pastExperience && pastExperience[0]){
                for(var j in pastExperience){
                    var bnd=pastExperience[j]
                    if (bnd.imgs && bnd.imgs[0]) {
                        bnd.imgs[0].path = `${config.imgDomain}${config.bandImages}/${bnd.imgs[0].path}`
                    }
                    if (bnd.mainImg ) {
                        bnd.mainImg.path = `${config.imgDomain}${config.bandImages}/${bnd.mainImg.path}`
                    }
                    let date=await this.dateModel.findById(bnd.dateId,'paradeS')
                    bnd.paradeS=date.paradeS
                    pastExperience[j]=bnd
                }
                pastExperience=pastExperience.sort((a,b)=> b.paradeS - a.paradeS)
            }
            return {
                band,
                bandDate,
                sections,
                lines,
                events,
                carnival,
                reviews,
                services: services.services,
                jouvertServices:services.jouvertServices,
                childrenServices:services.childrenServices,
                guides,
                comparisons: comparisons || [],
                dynamics,
                comments,
                awards,
                otherBandsInFY,
                thisBandInOtherFYs,
                CurrencyRates,
                galleries,
                news,
                pastExperience,
                bandDateDetails
            }
        } catch (error) {
            console.error(error);
            return { code: -1, msg: "Error occurred while getting band date with slug: " + params.slug }
        }
    }

    async compare(params): Promise<any> {
        try {
            var slugs = params.slugs
            slugs = slugs.split(',')
            var bands = []
            if (slugs && slugs[0] !== '') {
                for (let slug of slugs) {
                    let arraySlug = slug.split('~')
                    slug = arraySlug[0]
                    let data: any = await this.bandDateModel.find({ slug: slug })
                    data = data[0] || null
                    data = data && data.toObject()
                    if (data) {
                        if (data && data.mainImg && data.mainImg.path) data.mainImg.path = encoder(config.imgDomain + config.bandImages + '/' + data.mainImg.path);
                        if (data.lDate) data.lDate = moment(data.lDate).utc().format("ddd, MMM D YYYY");
                        if (data.rdDate) data.rdDate = moment(data.rdDate).utc().format("ddd, MMM D YYYY");
                        if (arraySlug && arraySlug[1]) {
                            var section: any = await this.sectionModel.findOne({ _id: arraySlug[1] }, 'name colors price img average designers')
                            section = section.toObject()
                            if (section.img && section.img.path)
                                section['img'].path = encoder(config.imgDomain + config.sectionImages + '/' + section['img'].path)
                            var lines: any = await this.lineModel.find({ sId: section._id }, 'styles price type addOns deposit gallery')
                            if (lines && lines[0]) {
                                lines = lines.map((line) => {
                                    line = line.toObject()
                                    let gallery = line.gallery || []
                                    let min = 0
                                    if (gallery && gallery[0]) {
                                        min = gallery[0].price
                                        gallery.map((g) => {
                                            if (!g.isAddOn) {
                                                if (g.price && g.price < min) min = g.price
                                            }
                                        })
                                    }
                                    line.minPrice = Math.round(min)
                                    return line
                                })
                            }
                            data['section'] = section
                            data['designers'] = section && section.designers
                            data['lines'] = lines
                            data['average'] = section && section.average || 0

                        }

                        var bandSections: any = await this.sectionModel.find({ bdId: data._id }, 'average')
                        if (bandSections && bandSections[0]) {
                            var sum = 0
                            bandSections.map((index) => sum += index.average)
                            let total = bandSections.length
                            let av:any = sum / total
                            av=(av)? av.toFixed(1) : 0
                            data['average'] = av
                            
                        }
                        // find score of band every year
                        var scoreBands = []
                        let bandId = data && data.bandId || 0
                        let sameBands = await this.bandDateModel.find({ bandId }, 'score year').sort('year')
                        if (sameBands && sameBands[0]) {
                            sameBands.forEach((x) => {
                                let obj = {
                                    score: x.score,
                                    year: x.year
                                }
                                scoreBands.push(obj)
                            })
                        }
                        var events: any = await this.eventModal.find({ dId: data.dateId }, "name type price slug sDate");

                        if (events && events[0]) {
                            events = events.map(ev => {
                                ev = ev.toObject()
                                var df =(ev.sDate)?moment(ev.sDate).utc().format("ddd, MMM D, YYYY").toString():''
                                ev.sDate = df
                                return ev
                            })
                        }
                        var awards = await this.awardModel.find({ 'cats.positions.bands._id': data._id }, '_id dId cats slug');
                        var festival = await this.dateModel.findOne({ _id: data.dateId }, "festival year");
                        data['scoreBands'] = scoreBands
                        data['festivalName'] = festival && festival.festival && festival.festival.name
                        data['year'] = festival && festival.year
                        data['events'] = events
                        data['awards'] = awards
                        bands.push(data)
                    }
                }
            }
            var allCarnival = await this.dateModel.find({}, 'year slug festival name')
            var allBands = await this.bandDateModel.find({}, 'slug name  year dateId isJouvertService isCustomeService isChildrenService')
            var allSec = await this.sectionModel.find({}, 'bdId name')
            var services = await this.dynamicModel.findOne({}, 'services jouvertServices childrenServices')
            return {
                code: 0, msg: "success", data: {
                    bands: bands,
                    carnivals: allCarnival,
                    allBands: allBands,
                    sections: allSec,
                    services: services
                }
            }
        } catch (error) {
            console.log(error)
            return { code: -1, msg: "error", data: {} }
        }
    }

    async updateReviews(body, user, req: Request): Promise<any> {
        try {
            let { review, docID, uniqueId } = body;
            if (user) {
                const userExists = await this.userModel.findById(user, "_id");
                if (!userExists) return { code: -1, msg: "User does not exist." };
            } else {
                if (!uniqueIdIsValid(uniqueId)) uniqueId = '';
                if (!uniqueId) {
                    let ip = req.ip;
                    let agent = req.headers['user-agent'];
                    let hash = md5(ip + agent);
                    let validator = md5(hash + salt);
                    uniqueId = hash + validator;
                }
            }
            user ||= uniqueId;
            let bandDateExists = await this.bandDateModel.findById(docID, "_id agree disagree notsure");
            if (!bandDateExists) return { code: -1, msg: "Band date does not exist." };
            const voteExists = await this.voteModel.findOne({ docID, userId: user, docType: 'band' });
            if (voteExists) {
                await voteExists.delete();
                bandDateExists[voteExists.vote]--;
            }
            await this.voteModel.create({
                docID,
                vote: review,
                userId: user,
                docType: 'band'
            });
            bandDateExists[review]++;
            await bandDateExists.save();
            return { code: 0, data: bandDateExists, msg: uniqueId };
        } catch (error) {
            return { code: -1, msg: "Error occurred while updating band date reviews.", data: error }
        }
    }
    async getBandsFestivalDate(query):Promise<any>{
        if(!query.id) return {code:-1,msg:"Not found",data:[]}
        const dateId=query.id
        let bands= await this.bandDateModel.find({dateId}, "slug name").sort({name:1});
        return {code:0,msg:"success",data:bands}
    }
}

function uniqueIdIsValid(input) {
    if (input) {
        let split1 = input.substring(0, 32);
        let split1Hash = md5(split1 + salt);
        let split2 = input.substring(32, 64);
        return split1Hash == split2;
    }
    return false;
}

export function encoder(url) {
    return encodeURI(url);
}
