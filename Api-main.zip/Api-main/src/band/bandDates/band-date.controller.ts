import { Body, Controller, Get, Param, Post, Query, Req, Res } from "@nestjs/common";
import { Request, Response } from "express";
import { BandDateService } from "./band-date.service";

@Controller('band-date')
export class BandDateController {
    constructor(private serviceBandDate: BandDateService) { }
    @Get("/filtered")
    async getBandDates(@Query() query): Promise<any> {
        return await this.serviceBandDate.getAll(query)
    }

    @Get("/slug/:slug")
    async getBytSlug(@Param() params, @Res() res: Response): Promise<any> {
      return res.json(await this.serviceBandDate.getBySlug(res.locals.userId, params));
    }
    @Get("/compare")
    async compare(@Query() query): Promise<any> {
        return await this.serviceBandDate.compare(query)
    }
    @Get("/festival")
    async getBandsFestivalDate(@Query() query): Promise<any> {
        return await this.serviceBandDate.getBandsFestivalDate(query)
    }

    @Post("/score/update")
    async updateScoreReviews(@Body() body, @Res() res: Response, @Req() req: Request): Promise<any> {
        res.json(await this.serviceBandDate.updateReviews(body, res.locals && res.locals.userId, req));
    }
}