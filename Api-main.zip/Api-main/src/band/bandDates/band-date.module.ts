import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AwardSchema } from 'src/award/award.schema';
import { BlogSchema } from 'src/blog/blog.schema.';
import { citySchema } from 'src/city/city.schema';
import { CommentSchema } from 'src/comment/comment.schema';
import { DatesSchema } from 'src/dates/dates.schema';
import { DynamicSchema } from 'src/dynamic/dynamic.schema';
import { EventSchema } from 'src/event/event.schema';
import { LineSchema } from 'src/line/line.schema';
import { SectionSchema } from 'src/section/section.schema';
import { UserSchema } from 'src/user/user.schema';
import { VoteSchema } from 'src/vote/vote.schema';
import { BandSchema } from '../band.schema';
import { BandDateController } from './band-date.controller';
import { bandDateSchema } from './band-date.schema';
import { CurrencyRateSchema } from 'src/currencyRate/currencyRate.schema';
import { BandDateService } from './band-date.service';
import { GallerySchema } from 'src/gallery/gallery.schema';

@Module({
    controllers: [BandDateController],
    providers: [BandDateService],
    imports: [MongooseModule.forFeature([
        { name: "BandDate", schema: bandDateSchema },
        { name: "Section", schema: SectionSchema },
        { name: "Line", schema: LineSchema },
        { name: "Dates", schema: DatesSchema },
        { name: "City", schema: citySchema },
        { name: "Band", schema: BandSchema },
        { name: "Blog", schema: BlogSchema },
        { name: "Event", schema: EventSchema },
        { name: "Award", schema: AwardSchema },
        { name: "Dynamic", schema: DynamicSchema },
        { name: "User", schema: UserSchema },
        { name: "Comment", schema: CommentSchema },
        { name: "Vote", schema: VoteSchema },
        { name: "CurrencyRate", schema: CurrencyRateSchema },
        { name: "Gallery", schema: GallerySchema },
    ])],

})
export class BandDateModule { }