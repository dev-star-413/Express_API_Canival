import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { BandDocument } from './band.schema';
import { Model } from 'mongoose';
import { DateDocument } from 'src/dates/dates.schema';
import { DynamicDocument } from 'src/dynamic/dynamic.schema';
import { DesignerDocument } from 'src/designer/designer.schema';
import getConfig from "src/config/config.service";
import { BandDateDocument } from './bandDates/band-date.schema';
import { AwardDocument } from 'src/award/award.schema';
import { BlogDocument } from 'src/blog/blog.schema.';
import { encoder } from 'src/band/bandDates/band-date.service';
import { GalleryDocument } from 'src/gallery/gallery.schema';

const config = getConfig();

@Injectable()
export class BandService {
    constructor(  
        @InjectModel("Band") private bandModel: Model<BandDocument>,
        @InjectModel("Date") private dateModel: Model<DateDocument>,
        @InjectModel("Dynamic") private dynamicModel: Model<DynamicDocument>,
        @InjectModel("Designer") private designerModel: Model<DesignerDocument>,
        @InjectModel("BandDate") private bandDateModel: Model<BandDateDocument>,
        @InjectModel("Award") private awardModel: Model<AwardDocument>,
        @InjectModel("Blog") private blogModel: Model<BlogDocument>,
        @InjectModel("Gallery") private galleryModel: Model<GalleryDocument>,
    ) { }

    async create(body): Promise<any> {
        let data = {
            name: body.name,
            desc: body.desc,
            theme: body.theme,
            type: body.type,
            launch: body.launch,
            carnival: body.carnival,
            sections: body.sections,
            slug: body.slug,
        }
        let newBand = await new this.bandModel(data)
        return newBand
    }

    async getFormParams(): Promise<any> {
        try {
            const designers = await this.designerModel.find({}, "_id name")
            const bands = await this.bandModel.find({}, "_id name")
            const dates = await this.dateModel.find({}, "_id festival year")
            const dynamics = await this.dynamicModel.findOne({}, "themes colors premiums services addOns revellers styles")
            const lineTypes = config.lineTypes;
            const sectionTypes = config.sectionTypes;
            return { designers, bands, dates, dynamics, lineTypes, sectionTypes }
        } catch (error) {
            return { code: -1, msg: "Error occurred while getting band form parameters." }
        }
    }

    async getFilterParams(): Promise<any> {
        try {
            const carnivals = await this.dateModel.find({}, "_id festival year");
            const bands = await this.bandModel.find({}, "_id name");
            const years = await this.bandDateModel.find({}).distinct("year");
            return { bands, carnivals, years }
        } catch (error) {
            console.log(error);
            return { code: -1, msg: "Error occurred while getting band filter parameters." }
        }
    }

    async getSome(params): Promise<any> {
        try {
            var num = JSON.parse(params.number)
            if (typeof num != 'number') return { code: -1, msg: "not valid" }
            return await this.bandModel.find({}).limit(num);
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    
    async get(params): Promise<any> {
        try {
            var band=await this.bandModel.findOne({ slug: params.slug },'slug name about img contactEmail contactPhone').lean();
            var bandDates=await this.bandDateModel.find({bandId:band._id},'name score dateName theme year slug mainImg imgs avgScore dateId').sort({rdDate:-1}).lean()
            var results=[]
            if(bandDates && bandDates[0]){
                for(var i in bandDates){
                    var bnd=bandDates[i]
                    if (bnd.mainImg && bnd.mainImg.path) {
                        bnd.mainImg.path = `${config.imgDomain}${config.bandImages}/${bnd.mainImg.path}`
                    }
                    let awards=await this.awardModel.find({'cats.positions.bands._id':bnd._id}).lean()

                    results=[...results,...awards]
                    let date=await this.dateModel.findById(bnd.dateId,'paradeS')
                    bnd.paradeS=date.paradeS
                    bandDates[i]=bnd
                }
                bandDates=bandDates.sort((a,b)=>{
                    return b.paradeS - a.paradeS;
                })
            }
            var news=await this.blogModel.find({'bands._id':band._id, cats:'News'},'slug title').lean()
            // var lastResult=await this.awardModel.find()
            if(band && band.img) {
                const address=encoder(`${config.imgDomain}${config.bandImages}/${band.img.path}`)
                band.img.path=address;
            } 
            // Gallery 
            var gallery:any=await this.galleryModel.find({'bands._id':band._id})
            for(let photo of gallery){
                var imgs:any=photo.imgs
                for(let img of imgs){
                  let {mime, path}=img
                  let newPath=(mime.includes('video'))? encoder('localhost:3000'+ config.videos + '/' + path):
                  encoder(config.imgDomain + config.galleryImages + '/' + path)
                  img.path=newPath
                }
              }
            return {code:0,msg:"success",band:{...band,bandDates,results,news, gallery}}
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    async like(params): Promise<any> {
        try {
            const blog = await this.bandModel.findOne({ slug: params.slug });
            await this.bandModel.updateOne({ slug: params.slug }, { likeC: blog.likeC.valueOf() + 1 });
            return await this.bandModel.findOne({ slug: params.slug }, { likeC: 1 });
        } catch (error) {
            return { code: -1, msg: error };
        }
    }
    
    async search(params): Promise<any>{
        try {
            var searchQ=new RegExp(`${params.q}`,'i')
            var all=[]
            var sort=params.sort || {lastYear:-1}
            if(sort=='az') sort={name:1}
            else if(sort=='year') sort={lastYear:-1}
            var bands =await this.bandModel.find({
                name:{
                    $regex:searchQ
                }},'name slug img').sort(sort).lean()
            for (var obj of bands){
            if(obj.img)  obj.img.path = `${config.imgDomain}${config.bandImages}/${obj.img.path}`
                let bandDates= await this.bandDateModel.find({bandId:obj._id},'name dateId dateName year mainImg slug').sort({year:-1}).limit(3).lean()
                all.push({
                    ...obj,
                    bandDates,
                    
                })
            }
            return {code:0,bands:all}
        } catch (error) {
            return {code:-1, msg:"Something is wrong, please try again."}
        }
    }
}