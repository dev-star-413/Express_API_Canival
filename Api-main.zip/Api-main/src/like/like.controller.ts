import { Body, Controller, Delete, Param, Patch, Post, Query, Res } from '@nestjs/common';
import { CreateLikeDTO } from './like.create.dto';
import { LikeService } from './like.service';

@Controller('like')
export class LikeController {
    constructor(private likeServices: LikeService) { }
    @Post()
    async addLike(@Body() Body: CreateLikeDTO, @Res() res): Promise<any> {
        return await this.likeServices.add(Body, res)
    }
    @Delete()
    async unLike(@Query() query, @Res() res): Promise<any> {
        return await this.likeServices.unlike(query, res)
    }
}
