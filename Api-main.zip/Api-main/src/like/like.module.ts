import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { LikeController } from './like.controller';
import { LikeSchema } from './like.schema';
import { LikeService } from './like.service';

@Module({
  imports:[MongooseModule.forFeature([{name:"Like",schema:LikeSchema}])],
  controllers: [LikeController],
  providers: [LikeService]
})
export class LikeModule {}
