import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

export type likeDocument = Like & Document;
@Schema()
export class Like {
    @Prop({ type: Object })
    userId: string;
    @Prop()
    collName: string;
    @Prop()
    docID: string;
    @Prop({ type: Date, default: Date.now })
    createAt: Date;
}
export const LikeSchema = SchemaFactory.createForClass(Like)