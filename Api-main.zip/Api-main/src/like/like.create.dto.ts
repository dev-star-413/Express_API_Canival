import { ApiProperty } from "@nestjs/swagger";

export class CreateLikeDTO{
    @ApiProperty({
        description:' like it'
    })
    isLike:boolean
    @ApiProperty({
        description:'user name and user id'
    })
    user:string
    @ApiProperty({
        description:"collection name"
    })
    collName:number
    @ApiProperty({
        description:""
    })
    docID:string
}