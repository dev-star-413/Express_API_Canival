import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { likeDocument } from './like.schema';

@Injectable()
export class LikeService {
    constructor(
        @InjectModel("Like") private LikeModel: Model<likeDocument>
    ) { }
    async add(params, res): Promise<any> {
        const { user, collName, docID } = params
        if (!collName || !docID) return " send collName and docId"
        let userId = res.locals.userId
        if (!userId) return "not found user"
        const data = {
            userId: user,
            collName: collName,
            docID: docID,
        }
        const newLike = await this.LikeModel.create(data);
        return newLike;
    }
    async unlike(param, res): Promise<any> {
        let { collName, docID, user } = param;
        let userId = res.locals.userId;
        if (!userId) return { code: -1, msg: "user not found", data: {} }
        if (collName && docID) {
            let result = await this.LikeModel.remove({
                collName: collName,
                docID: docID,
                userId: user
            })
            return result ? 1 : -1;
        }
        return { code: 0, msg: "send collName and docID" };
    }
}
