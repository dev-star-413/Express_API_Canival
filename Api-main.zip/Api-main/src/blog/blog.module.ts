import { Module } from '@nestjs/common';
import { InjectModel, MongooseModule } from '@nestjs/mongoose';
import { BlogController } from './blog.controller';
import { BlogSchema } from './blog.schema.';
import { BlogService } from './blog.service';

@Module({
    providers:[BlogService],
    controllers:[BlogController],
    imports:[MongooseModule.forFeature([{name:"Blog",schema:BlogSchema}])]
})
export class BlogModule {}
