import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
export type BlogDocument = Blog & Document;
@Schema()
export class Blog {
  @Prop()
  title: string;
  @Prop()
  author: string;
  @Prop()
  pDate: Date;
  @Prop({ type: Object })
  cats: object;
  @Prop()
  meta: string;
  @Prop()
  desc: string;
  @Prop({ type: Object })
  img: {
    name: string;
    path: string;
    mime: string;
  };
  @Prop()
  imgt: string;
  @Prop({ type: [Object] })
  cities: [object];
  @Prop({ type: [Object] })
  festivals: [object];
  @Prop({ type: [Object] })
  bands: Array<{
    _id: string;
    name: string;
  }>;
  @Prop({ type: [Object] })
  designers: [object];
  @Prop({ type: [Object] })
  artists: [object];
  @Prop()
  slug: string;
  @Prop()
  likeC: number;
  @Prop({ default: 0 })
  commentC: number;
  @Prop({ type: [Object], default: [] })
  comments: Array<{
    id: string;
    pId: string;
    userId: string;
    name: string;
    comment: string;
    createAt: any;
  }>;
  @Prop()
  isTop: boolean;
  @Prop()
  isFeature: boolean;
  @Prop()
  isMain: boolean;
  @Prop({ required: true, default: Date.now })
  createAt: Date;
  @Prop()
  deleteAt: Date;
  @Prop({default: 0})
  view: Number;
}
export const BlogSchema = SchemaFactory.createForClass(Blog);
