import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { CreateBlogDTO } from './blog.create.dto';
import { BlogService } from './blog.service';
import { GetBlogsDto } from './dto/getBlogs.dto'

@Controller('blog')
export class BlogController {
    constructor(private blogService: BlogService) { }
    @Get('/:slug')
    async get(@Param() param): Promise<any> {
        return await this.blogService.get(param);
    }
    @Get()
    async getAll(@Query() query: GetBlogsDto): Promise<any> {
      let filterQuery: any = {};
      if(query.cats) {
        if(!Array.isArray(query.cats)) {
          query.cats = [query.cats]
        } 
        filterQuery["$or"] = [];
        for(let cat of query.cats) {
          filterQuery["$or"].push({cats: cat})
        }
      }

      if(query.festival) {
        filterQuery["festivals.slug"] = query.festival
      }
      if(query.city) {
        filterQuery["cities.slug"] = query.city
      }
      if(query.designer) {
        filterQuery["designers.slug"] = query.designer
      }
      if(query.band) {
        filterQuery["bands.slug"] = query.band
      }

      const topBlogs = await this.blogService.findSortLimit(
        {...filterQuery},
        'title meta img cats slug author pDate',
        {view: -1},
        5
      );
      const featureBlogs = await this.blogService.findSortLimit(
        {...filterQuery, isFeature: true},
        'title meta img cats slug author pDate',
        {isMain: -1, pDate: -1}
      );
      const latestBlogs = await this.blogService.findSortLimit(
        {...filterQuery, isFeature: true},
        'title meta img cats slug author pDate',
        { createAt:1},
        5
      );
      return {topBlogs, featureBlogs,latestBlogs};
    }
    @Get("/like/:slug")
    async like(@Param() params) {
        return await this.blogService.like(params);
    }
    @Post("/create")
    async create(@Body() body: CreateBlogDTO): Promise<any> {
        return await this.blogService.create(body)
    }
}
