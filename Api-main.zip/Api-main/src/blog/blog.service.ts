import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FilterQuery, Model } from 'mongoose';
import { BlogDocument } from './blog.schema.';
import getConfig from "src/config/config.service";
import * as moment from "moment";
import { encoder } from 'src/band/bandDates/band-date.service';
const config = getConfig();

@Injectable()
export class BlogService {
  constructor(@InjectModel('Blog') private blogModel: Model<BlogDocument>) { }
  async get(params): Promise<any> {
    try {
      let blog = await this.blogModel.findOneAndUpdate({
        slug: params.slug,
        img: { $ne: null },
      },{$inc:{view:+1}});
      if (!blog) return null

      if (blog && blog.img) {
        blog.img = modifyImagePaths(blog.img);
      }
      if (blog.comments) {
        blog.comments = blog.comments.reverse();
        blog.comments.map(review => {
          const dif = moment().diff(review.createAt, 'd');
          if (dif < 1) {
            review.createAt = moment(review.createAt).format("HH:mm");
          } else if (dif == 1) {
            review.createAt = "yesterday";
          } else if (dif <= 7) {
            review.createAt = moment(review.createAt).weekday(review.createAt);
          } else {
            review.createAt = moment(review.createAt).utc().format("YYYY-MM-DD HH:mm");
          }
        })
      }
      let more = await this.blogModel
        .find(
          { cats: blog && blog.cats, _id: { $ne: blog && blog._id }, img: { $ne: null } },
          'slug img title meta author pDate',
        ).sort({view:-1}).limit(5);
        more.map((blg) => {
        if (blog && blg.img) {
          blg.img = modifyImagePaths(blog && blg.img);
        }
      });
      return { blog, more };
    } catch (error) {
      console.error(error);
      return {
        code: -1,
        msg: 'Error occurred while getting blog ' + params.slug,
      };
    }
  }

  async findSortLimit(query: FilterQuery<BlogDocument>, projection?: any, sort?: any, limit?: number) {
    let blogs = await this.blogModel.find(query, projection).sort(sort).limit(limit);
    blogs.map((blog) => {
      blog.img = modifyImagePaths(blog.img);
    });
    return blogs;
  }

  async like(params): Promise<any> {
    try {
      const blog = await this.blogModel.findOne({ slug: params.slug });
      await this.blogModel.updateOne(
        { slug: params.slug },
        { likeC: blog.likeC.valueOf() + 1 },
      );
      return await this.blogModel.findOne({ slug: params.slug }, { likeC: 1 });
    } catch (error) {
      return { code: -1, msg: error };
    }
  }
  async create(body): Promise<any> {
    try {
      if (body) {
        const res = await this.blogModel.create(body);
        return { code: 1, data: res };
      }
      return { code: -1, msg: 'Fill entire fields' };
    } catch (error) {
      return { code: -1, msg: error };
    }
  }
}

function modifyImagePaths(img) {
  if (img) {
    img.path = encoder(`${config.imgDomain}${config.blogImages}/${img.path}`);
  }
  return img;
}
