export class CreateBlogDTO{
    title: string
    desc: string
    sDesc: string
    pDate: Date
    cats: any
    imgs: any
    city: any
    carnival: any
    band: any
    designer: any
}