export class GetBlogsDto {
  cats: [String];
  festival?: string;
  city?: string;
  designer?: string;
  band?: string;
}