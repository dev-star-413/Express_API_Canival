import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

@Schema()
export class Line {
    @Prop()
    sId: string;
    @Prop()
    type: string;
    @Prop({ trim: true })
    includes: string;
    @Prop({ type: [Object] })
    addOns: Array<{
        title: string,
        price: string,
        img: {
            name: string,
            path: string,
            mime: string
        }
    }>
    @Prop({ type: [Object], default: [] })
    imgs: Array<{
        name: string;
        path: string;
        mime: string;
    }>
    @Prop({ type: [Object] })
    gallery: Array<{
        _id: string;
        name: string;
        path: string;
        mime: string;
        text: string;
        price: number;
        currency: string;
        isAddOn: boolean;
        includes: string;
    }>
    @Prop()
    price: number;
    @Prop()
    deposit: number;
    @Prop()
    lDate: Date;
    @Prop()
    rdDate: Date;
    @Prop({ trim: true })
    desc: string;
    @Prop({ type: Array })
    styles: Array<string>
    @Prop({ trim: true })
    link: string;
    @Prop()
    sold: number;
    @Prop()
    currency:String
}

export type LineDocument = Line & Document;
export const LineSchema = SchemaFactory.createForClass(Line);