import { Body, Controller, Post, Res } from '@nestjs/common';
import { Response } from 'express';
import { EventTempService } from './event-temp.service';

@Controller('event-temp')
export class EventTempController {
  constructor(private readonly eventTempService: EventTempService) { }
  @Post('/create')
  async create(@Body() body, @Res() res: Response): Promise<any> {
    res.json(await this.eventTempService.create(body, res.locals.userId))
  }
}
