import { Test, TestingModule } from '@nestjs/testing';
import { EventTempController } from './event-temp.controller';
import { EventTempService } from './event-temp.service';

describe('EventTempController', () => {
  let controller: EventTempController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [EventTempController],
      providers: [EventTempService],
    }).compile();

    controller = module.get<EventTempController>(EventTempController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
