import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CityDocument } from 'src/city/city.schema';
import { UserDocument } from 'src/user/user.schema';
import { EventTempDocument } from './event-temp.schema';

@Injectable()
export class EventTempService {
    constructor(
        @InjectModel('EventTemp') private eventTempModel: Model<EventTempDocument>,
        @InjectModel('User') private userModel: Model<UserDocument>,
        @InjectModel('City') private cityModel: Model<CityDocument>,
    ) { }

    async create(body, userId): Promise<any> {
        try {
            const user = await this.userModel.findById(userId, '_id');
            let {
                name,
                // city,
                dId,
                vName,
                vAddress,
                frequency,
                sDate,
                eDate,
                mGenre,
                types,
                pitch,
                price,
                link,
                desc,
            } = body;
            if (user) {
                // const city = await this.cityModel.findById(body.city, "_id name")
                var data = {
                    name,
                    // city,
                    dId,
                    vName,
                    vAddress,
                    frequency,
                    sDate,
                    eDate,
                    mGenre,
                    types,
                    pitch,
                    price,
                    link,
                    desc,
                    by: userId,
                }
                await this.eventTempModel.create(data);
                return { code: 1, msg: 'Your event posted to the EventTemp successfully!' }
            }
            return { code: 0, msg: 'Uesr account not found.' }
        } catch (error) {
            return { code: -1, msg: 'Error occurred while creating event temp.' }
        }
    }
}
