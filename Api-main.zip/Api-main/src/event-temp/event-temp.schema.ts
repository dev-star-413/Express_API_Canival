import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type EventTempDocument = EventTemp & Document;
@Schema()
export class EventTemp {
    @Prop({ type: String })
    dId: string
    @Prop({ type: String })
    name: string
    @Prop({ type: String, trim: true })
    vName: string // venue name
    @Prop({ type: String, trim: true })
    vAddress: string // venue address
    @Prop({ type: String, trim: true })
    pitch: string// a summery text (150 characters)
    @Prop({ type: String, trim: true })
    desc: string
    @Prop({ type: Object })
    city: {
        id: String,
        name: String
    }
    @Prop({ type: Date })
    sDate: any
    @Prop({ type: Date })
    eDate: any
    @Prop({ type: Object, default: [] })
    types: Object
    @Prop({ type: String, trim: true })
    mGenre: string// music genre
    @Prop({ type: Object })
    @Prop()
    by: string;
    @Prop({ default: new Date() })
    at: Date;
    @Prop({ default: false })
    confirmed: boolean;
    @Prop()
    confirmedDate: Date;
    @Prop()
    confirmedBy: string;
    @Prop({ type: [Object], default: [] })
    imgs: Array<{
        name: string,
        path: string,
        mime: string
    }>
    @Prop({ type: Boolean, default: false })
    canceled: boolean
    @Prop({ type: Number, default: 0 })
    likeC: number // like count
    @Prop({ type: Number, default: 0 })
    commentC: number // comment count
    @Prop({ type: Object, default: [] })
    comments: Object // last 10 comments
    @Prop({ type: Number })
    price: number
    @Prop({ type: String, trim: true })
    link: string // link for buying ticket
    @Prop({ type: Date, default: Date.now })
    createAt: Date
    @Prop({ type: String, trim: true })
    slug: string
    @Prop({ type: Object })
    location: Object
    @Prop({type:String,default:"USD"})
    currency:string
}
export const EventTempSchema = SchemaFactory.createForClass(EventTemp);