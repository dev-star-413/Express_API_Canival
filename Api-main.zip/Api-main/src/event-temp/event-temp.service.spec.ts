import { Test, TestingModule } from '@nestjs/testing';
import { EventTempService } from './event-temp.service';

describe('EventTempService', () => {
  let service: EventTempService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [EventTempService],
    }).compile();

    service = module.get<EventTempService>(EventTempService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
