import { Module } from '@nestjs/common';
import { EventTempService } from './event-temp.service';
import { EventTempController } from './event-temp.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { EventTempSchema } from './event-temp.schema';
import { UserSchema } from 'src/user/user.schema';
import { citySchema } from 'src/city/city.schema';

@Module({
  imports: [MongooseModule.forFeature([
    { name: 'EventTemp', schema: EventTempSchema },
    { name: 'User', schema: UserSchema },
    { name: 'City', schema: citySchema },
  ])],
  controllers: [EventTempController],
  providers: [EventTempService]
})
export class EventTempModule { }
