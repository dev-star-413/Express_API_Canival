import { Module } from '@nestjs/common';
import { DynamicService } from './dynamic.service';
import { DynamicController } from './dynamic.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { DynamicSchema } from './dynamic.schema';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'Dynamic', schema: DynamicSchema }])],
  controllers: [DynamicController],
  providers: [DynamicService]
})
export class DynamicModule { }
