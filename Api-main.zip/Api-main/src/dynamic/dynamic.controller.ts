import { Controller, Get } from '@nestjs/common';
import { DynamicService } from './dynamic.service';

@Controller('dynamic')
export class DynamicController {
  constructor(private readonly dynamicService: DynamicService) { }
  @Get('/services')
  async getServices(): Promise<any> {
    return await this.dynamicService.getServices();
  }
}
