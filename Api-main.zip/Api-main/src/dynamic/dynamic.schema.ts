import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema()
export class Dynamic {
    @Prop({ type: Array, default: [] })
    themes: Array<String>
    @Prop({ type: Array, default: [] })
    colors: Array<String>
    @Prop({ type: Array, default: [] })
    premiums: Array<String>
    @Prop({ type: Array, default: [] })
    categories: Array<String>
    @Prop({ type: Array, default: [] })
    services: Array<String> // costume services
    @Prop({ type: Array, default: [] })
    jouvertServices: Array<String> 
    @Prop({ type: Array, default: [] })
    addOns: Array<String>
    @Prop({ type: Array, default: [] })
    standards: Array<String>
    @Prop({ type: Array, default: [] })
    revellers: Array<String>
    @Prop({ type: Array, default: [] })
    styles: Array<String>
    @Prop({ type: Array, default: [] })
    awardTypes: Array<String>
    @Prop({ type: Array, default: [] })
    festivalTypes: Array<String>
    @Prop({ type: Array, default: [] })
    faqCategories: Array<String>
    @Prop({ type: Array, default: [] })
    regions: Array<String>
    @Prop({type:Array,default:[]})
    childrenServices:Array<String>
    @Prop({type:String})
    bandDateDetails:string

}

export type DynamicDocument = Dynamic & Document;
export const DynamicSchema = SchemaFactory.createForClass(Dynamic);