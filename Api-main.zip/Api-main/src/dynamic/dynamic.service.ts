import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { DynamicDocument } from './dynamic.schema';

@Injectable()
export class DynamicService {
    constructor(@InjectModel("Dynamic") private dynamicModel: Model<DynamicDocument>) { }

    async getServices(): Promise<any> {
        const data = await this.dynamicModel.findOne({}, "services");
        return data.services;
    }
}
