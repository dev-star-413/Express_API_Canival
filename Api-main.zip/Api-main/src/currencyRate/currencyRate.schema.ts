import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CurrencyRateDocument = CurrencyRate & Document;

@Schema()
export class CurrencyRate {
  @Prop({type:String})
  country:string// country (to) 
  @Prop({type:String})
  from:string
  @Prop({type:String,default:"USD"})
  to:string
  @Prop({type:String})
  rate:string
  @Prop({type:Date,default:new Date()})
  updateAt:Date
  @Prop({type:String})
  symbol:string
  // createAt: { type: Date, default: Date.now }
  // deleteAt: { type: Date }
}

export const CurrencyRateSchema = SchemaFactory.createForClass(CurrencyRate)