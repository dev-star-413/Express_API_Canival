import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CurrencyRateSchema } from './currencyRate.schema';

@Module({
    imports:[MongooseModule.forFeature([{ name: 'CurrencyRate', schema: CurrencyRateSchema }])],
    exports:[MongooseModule.forFeature([{ name: 'CurrencyRate', schema: CurrencyRateSchema }])]
})
export class TokenModule {}
