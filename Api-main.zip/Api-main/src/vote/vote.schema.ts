import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type VoteDocument = Vote & Document;

@Schema()
export class Vote {
    @Prop()
    docID: string;
    @Prop()
    docType: string;
    @Prop()
    subId: string;
    @Prop()
    userId: string; // userId || Hash(IP + user agent)
    @Prop()
    vote: string;
    @Prop()
    rate: number;
}

export const VoteSchema = SchemaFactory.createForClass(Vote);