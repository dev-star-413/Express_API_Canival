import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { NewsDocument } from './news.schema';

@Injectable()
export class NewsService {
    constructor(@InjectModel('News') private newsModel:Model<NewsDocument>){}
    async create(params):Promise<any>{
        try {
            let data={
                title:params.title,
                sTitle: params.sTitle,
                sDesc: params.sDesc,
                desc: params.desc,
                imgs:params.imgs,
                active: params.active,

            }
            let news=await new this.newsModel(data)
            return news.save()
        } catch (error) {
            throw error
        }
    }
    async getAll(params):Promise<any>{
        try {
            let news=await this.newsModel.find().exec();
            return news;
        } catch (error) {
            throw error;
        }
        // read all news
    }
    async get(params):Promise<any>{
        // get news 
        try {
            let id=params.id;
            let news=await this.newsModel.find({_id:id}).exec()
            return news;
        } catch (error) {
            throw error;
        }
    }
    

}
