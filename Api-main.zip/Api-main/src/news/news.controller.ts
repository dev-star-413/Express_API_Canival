import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { NewsService } from './news.service';

@Controller('news')
export class NewsController {
    constructor(private newsService:NewsService){}
    @Post()
    async create(@Body() body):Promise<any>{
        let news=await this.newsService.create(body);
        return news;
    }
    @Get()
    async getAll(@Query() query):Promise<any>{
        let news =await this.newsService.getAll(query)
        return news;
    }
    @Get('/:id')
    async getByID (@Param() params):Promise<any>{
        try{
            let news=await this.newsService.get(params);
            return news;
        }catch(e){
            console.error(e)
        }
    }
}
