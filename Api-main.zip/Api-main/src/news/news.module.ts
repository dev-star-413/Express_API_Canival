import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { NewsController } from './news.controller';
import { NewsSchema } from './news.schema';
import { NewsService } from './news.service';

@Module({
    controllers:[NewsController],
    providers:[NewsService],
    imports:[MongooseModule.forFeature([{ name: 'News', schema: NewsSchema }])]
})
export class NewsModule {}
