import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Mongoose } from 'mongoose';

export type NewsDocument=News& Document;
@Schema()
export class News{
    @Prop()
    dId: string // festival date Id
    @Prop()
    title:string;
    @Prop()
    sTitle:string;
    @Prop()
    sDesc:string;
    @Prop()
    desc:string;
    @Prop({type:Object})
    img:object;
    @Prop()
    active:boolean;
    @Prop({required:true,default:Date.now})
    createAt: Date;
    @Prop()
    deleteAt:Date
}
export const NewsSchema=SchemaFactory.createForClass(News);