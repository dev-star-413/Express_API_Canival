import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { FestivalDocument } from 'src/festival/festival.schema';
import { FYearDocument } from './festival-year.schema';

@Injectable()
export class FestivalYearService {
    constructor(
        @InjectModel('FestivalYear') private FYearModel: Model<FYearDocument>,
        @InjectModel('Festival') private FestivalModel:Model<FestivalDocument>){}
    async get(param){
        // filter by year 
        let year=param.year
        return await this.FYearModel.find({year})
    }
    async getById(param){
        let fy= await this.FYearModel.findById(param.id)
        let fID=fy.festival['id']
        let f= await this.FestivalModel.findOne({
            _id:fID,
            deleteAt:{$exists:false}
        })
        let{createAt,deleteAt,...festival}=f
        festival={...fy,...festival}
       return festival
    }
}
