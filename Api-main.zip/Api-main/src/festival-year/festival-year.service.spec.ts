import { Test, TestingModule } from '@nestjs/testing';
import { FestivalYearService } from './festival-year.service';

describe('FestivalYearService', () => {
  let service: FestivalYearService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FestivalYearService],
    }).compile();

    service = module.get<FestivalYearService>(FestivalYearService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
