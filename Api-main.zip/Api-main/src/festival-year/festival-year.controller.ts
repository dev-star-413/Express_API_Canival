import { Controller, Get, Param, Query } from '@nestjs/common';
import { FestivalYearService } from './festival-year.service';

@Controller('festival-year')
export class FestivalYearController {
    constructor(private fYearService:FestivalYearService){}
    @Get()
    async get(@Query() query){
        return await this.fYearService.get(query);
    }
    @Get('/:id')
    async getById(@Param() param){
        return await this.fYearService.getById(param)
    }
}
