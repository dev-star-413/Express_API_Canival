import { Test, TestingModule } from '@nestjs/testing';
import { FestivalYearController } from './festival-year.controller';

describe('FestivalYearController', () => {
  let controller: FestivalYearController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FestivalYearController],
    }).compile();

    controller = module.get<FestivalYearController>(FestivalYearController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
