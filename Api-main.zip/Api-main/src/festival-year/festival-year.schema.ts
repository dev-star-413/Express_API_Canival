import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type FYearDocument = FestivalYear & Document;
@Schema()
export class FestivalYear {
  // _id,
  @Prop({ type: Object })
  festival: Object; //{id, name}
  @Prop()
  year: Number;
  @Prop()
  about: string;
  @Prop()
  tsk: string; // travelers should know
  @Prop({ type: Object })
  city: Object; //{id, name}
  @Prop({ type: Date, default: Date.now })
  createAt: Date;
}
export const FYearSchema = SchemaFactory.createForClass(FestivalYear);