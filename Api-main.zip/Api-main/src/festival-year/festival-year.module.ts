import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { FYearSchema } from './festival-year.schema';
import { FestivalYearController } from './festival-year.controller';
import { FestivalYearService } from './festival-year.service';
import { FestivalSchema } from 'src/festival/festival.schema';

@Module({
    imports:[MongooseModule.forFeature([
        { name: 'FestivalYear', schema: FYearSchema },
        {name:'Festival',schema:FestivalSchema}
    ])],
    exports:[MongooseModule.forFeature([{ name: 'FestivalYear', schema: FYearSchema }])],
    controllers: [FestivalYearController],
    providers: [FestivalYearService]
})

export class FestivalYearModule {}
